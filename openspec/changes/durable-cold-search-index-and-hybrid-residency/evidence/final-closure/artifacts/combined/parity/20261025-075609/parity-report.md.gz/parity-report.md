# LOCAL CI-PARITY (this Windows host) -- NOT hosted GitHub Actions evidence

- Label: LOCAL-PARITY-NOT-HOSTED-CI
- Source: e5b006dc9255931a41ff8fa135198f688d093434 branch=validation/three-pr-final-20261024 dirty=False
- Overall: FAIL (pass=8 fail=3 skipped=0)

| step | hosted ref | status | exit | duration ms | reason |
|---|---|---|---|---|---|
| preflight | ci.yml:37-45 toolchain discovery | PASS | 0 | 4798 |  |
| policy | ci.yml:26-32,75-81,126-132 markers + diagnostic policy + drift + diff-check | PASS | 0 | 12575 |  |
| openspec | ci.yml:134-136 openspec validate --all --strict | PASS | 0 | 4931 |  |
| build-debug | ci.yml:9-63 build[debug] | PASS | 0 | 7226 |  |
| build-release-test | ci.yml:9-63 build[release-test] | FAIL | 1 | 166512 | exit-code-1 |
| build-analyze | ci.yml:9-63 build[analyze] | PASS | 0 | 5657 |  |
| ctest-debug | ci.yml:51-63 ctest --preset debug | FAIL | 8 | 274882 | exit-code-8 |
| ctest-release-test | ci.yml:51-63 ctest --preset release-test | FAIL | 8 | 236404 | exit-code-8 |
| asan-slice | ci.yml:83-114 asan 4 targets + 4 tests | PASS | 0 | 69751 |  |
| hygiene-suite | ci.yml:116-181 status + contracts + visual + exact-tree | PASS | 0 | 88234 |  |
| release-candidate | ci.yml:183-224 unsigned release qualification | PASS | 0 | 335130 |  |

## Hosted-only omissions (never simulated)
- actions/checkout fetch, actions/upload-artifact retention, runner image/timeout enforcement, ::error annotations, workflow-command output, job-isolation freshness, npx registry fetch provenance.
