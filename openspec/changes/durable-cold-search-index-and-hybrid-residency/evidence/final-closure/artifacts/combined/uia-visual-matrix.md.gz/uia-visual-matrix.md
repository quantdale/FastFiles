# UIA Long-Run Certification: visual-matrix

- **Category**: uia
- **Disposition**: **PASS**
- **Commit**: `e5b006dc9255931a41ff8fa135198f688d093434` (tree: `2069796b1dbd10cdd5d3558f73d30d2e1b29116e`, exact: True)
- **Requested Iterations**: 25
- **Completed Iterations**: 25
- **Passed**: 25
- **Failed**: 0
- **Timed Out**: 0
- **Min / Median / P95 / Max**: 26743.41ms / 27614.73ms / 28017.86ms / 28125.97ms
