# LOCAL CI-PARITY (this Windows host) -- NOT hosted GitHub Actions evidence

- Label: LOCAL-PARITY-NOT-HOSTED-CI
- Source: db7887c1ec1d3d8f493848a9050240407423e678 branch=feat/durable-cold-search-and-hybrid-residency dirty=False
- Overall: PASS (pass=11 fail=0 skipped=0)

| step | hosted ref | status | exit | duration ms | reason |
|---|---|---|---|---|---|
| preflight | ci.yml:37-45 toolchain discovery | PASS | 0 | 3245 |  |
| policy | ci.yml:26-32,75-81,126-132 markers + diagnostic policy + drift + diff-check | PASS | 0 | 2636 |  |
| openspec | ci.yml:134-136 openspec validate --all --strict | PASS | 0 | 4550 |  |
| build-debug | ci.yml:9-63 build[debug] | PASS | 0 | 11999 |  |
| build-release-test | ci.yml:9-63 build[release-test] | PASS | 0 | 20751 |  |
| build-analyze | ci.yml:9-63 build[analyze] | PASS | 0 | 411956 |  |
| ctest-debug | ci.yml:51-63 ctest --preset debug | PASS | 0 | 263782 |  |
| ctest-release-test | ci.yml:51-63 ctest --preset release-test | PASS | 0 | 227239 |  |
| asan-slice | ci.yml:83-114 asan 4 targets + 4 tests | PASS | 0 | 73979 |  |
| hygiene-suite | ci.yml:116-181 status + contracts + visual + exact-tree | PASS | 0 | 91146 |  |
| release-candidate | ci.yml:183-224 unsigned release qualification | PASS | 0 | 50334 |  |

## Hosted-only omissions (never simulated)
- actions/checkout fetch, actions/upload-artifact retention, runner image/timeout enforcement, ::error annotations, workflow-command output, job-isolation freshness, npx registry fetch provenance.
