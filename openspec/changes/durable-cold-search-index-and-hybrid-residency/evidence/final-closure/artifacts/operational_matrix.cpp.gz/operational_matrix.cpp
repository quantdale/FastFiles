// Final-closure validation-only driver. Links the clean db7887c production
// Store and SQLite libraries; no product overrides, allocator probes or user DBs.
#include "ffindexstore/Store.h"
#include <Windows.h>
#include <psapi.h>
#include <algorithm>
#include <chrono>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <tuple>
#include <vector>

using namespace ffindexstore;
using Clock = std::chrono::steady_clock;
static uint64_t PrivateBytes() {
    PROCESS_MEMORY_COUNTERS_EX info{};
    info.cb = sizeof(info);
    return GetProcessMemoryInfo(GetCurrentProcess(), reinterpret_cast<PROCESS_MEMORY_COUNTERS*>(&info), sizeof(info)) ? info.PrivateUsage : 0;
}
static EntryRecord Row(uint64_t id, std::u16string name) {
    EntryRecord row;
    row.id = {id, 0}; row.parentId = {5, 0}; row.name = std::move(name);
    row.sizeBytes = id * 7; row.allocatedSizeBytes = id * 8;
    row.allocatedSizeKnown = true; row.creationTime = id + 1;
    row.lastModifiedTime = id + 2; row.lastAccessTime = id + 3;
    row.attributes = 32;
    return row;
}
static bool Same(const EntryRecord& a, const EntryRecord& b) {
    return a.id == b.id && a.parentId == b.parentId && a.name == b.name &&
        a.sizeBytes == b.sizeBytes && a.allocatedSizeBytes == b.allocatedSizeBytes &&
        a.allocatedSizeKnown == b.allocatedSizeKnown && a.creationTime == b.creationTime &&
        a.lastModifiedTime == b.lastModifiedTime && a.lastAccessTime == b.lastAccessTime &&
        a.attributes == b.attributes;
}
static uint64_t Bytes(const std::string& path) {
    std::error_code error;
    const auto size = std::filesystem::file_size(path, error);
    return error ? 0 : size;
}
int main(int argc, char** argv) {
    if (argc != 3) return 2; // Caller owns this synthetic directory and output.
    const std::string path = argv[1];
    if (std::filesystem::exists(path)) return 3;
    std::ofstream out(argv[2]); if (!out) return 3;
    Store store; if (!store.Open(path)) return 1;
    const auto v1 = store.GetOrCreateVolume({{}, 901});
    const auto v2 = store.GetOrCreateVolume({{}, 902});
    if (!v1 || !v2) return 1;
    const auto start = Clock::now();
    for (int volume = 0; volume < 2; ++volume) {
        std::vector<EntryChange> batch; batch.reserve(8192);
        for (uint64_t index = 0; index < 1000000; ++index) {
            std::u16string name = u"ordinary_filler.txt";
            if (volume == 0) {
                if (index < 16383) name = u"cap_boundary_a.txt";
                else if (index < 32767) name = u"cap_boundary_b.txt";
                else if (index < 49152) name = u"cap_boundary_c.txt";
                else if (index < 49154) name = u"local_selective_phrase.txt";
            } else if (index < 50000) name = u"local_selective_phrase.txt";
            batch.push_back({EntryChangeKind::Upsert, Row(100 + index, std::move(name))});
            if (batch.size() == 8192 || index == 999999) {
                if (!store.ApplyBatch(volume == 0 ? *v1 : *v2, batch)) return 1;
                batch.clear(); store.CheckpointIfWalExceeds(4000ull * 4096ull);
            }
        }
    }
    if (store.CountEntries(*v1) != 1000000 || store.CountEntries(*v2) != 1000000) return 1;
    out << "{\"schema\":\"closure-store-operational-v1\",\"production_library_source\":\"db7887c1ec1d3d8f493848a9050240407423e678\",\"fixture_rows\":2000000,\"ingestion_ms\":"
        << std::chrono::duration<double, std::milli>(Clock::now() - start).count() << ",\"cells\":[";
    struct Cell { const char* needle; VolumeRowId volume; size_t count; bool admitted; };
    const std::vector<Cell> cells{{"local_selective_phrase", *v1, 2, true},
        {"local_selective_phrase", *v2, 50000, false},
        {"cap_boundary_a", *v1, 16383, true}, {"cap_boundary_b", *v1, 16384, true},
        {"cap_boundary_c", *v1, 16385, false}, {"missing_phrase", *v1, 0, true}};
    bool first = true;
    for (int cycle = 0; cycle < 3; ++cycle) {
        for (const auto& cell : cells) {
            bool used = false; size_t counted = 0;
            auto session = store.OpenReadSession({{}, [&](bool value, size_t count) { used = value; counted = count; }});
            if (!session) return 1;
            std::vector<EntryRecord> indexed, canonical;
            const std::string needle(cell.needle);
            const std::u16string literal(needle.begin(), needle.end());
            const auto queryStart = Clock::now();
            if (!session->ForEachEntryWithAsciiNameUntil(cell.volume, needle, [&](const EntryRecord& row) {
                if (row.name.find(literal) != std::u16string::npos) indexed.push_back(row);
                return true;
            })) return 1;
            const auto queryMs = std::chrono::duration<double, std::milli>(Clock::now() - queryStart).count();
            // Independent full stream and plain literal predicate, no FTS/LIKE prefilter.
            size_t canonicalRows = 0;
            if (!session->ForEachEntryUntil(cell.volume, [&](const EntryRecord& row) {
                ++canonicalRows;
                if (row.name.find(literal) != std::u16string::npos) canonical.push_back(row);
                return true;
            })) return 1;
            const auto less = [](const EntryRecord& a, const EntryRecord& b) { return a.id < b.id; };
            std::sort(indexed.begin(), indexed.end(), less); std::sort(canonical.begin(), canonical.end(), less);
            const bool equal = indexed.size() == cell.count && canonical.size() == cell.count &&
                std::equal(indexed.begin(), indexed.end(), canonical.begin(), Same);
            const bool ok = equal && canonicalRows == 1000000 && used == cell.admitted;
            if (!first) out << ','; first = false;
            out << "{\"cycle\":" << cycle << ",\"needle\":\"" << needle << "\",\"volume\":" << cell.volume
                << ",\"count\":" << indexed.size() << ",\"candidate_route\":" << (used ? "true" : "false")
                << ",\"counted\":" << counted << ",\"canonical_rows\":" << canonicalRows
                << ",\"query_ms\":" << queryMs << ",\"full_metadata_equal\":" << (equal ? "true" : "false")
                << ",\"pass\":" << (ok ? "true" : "false") << '}'; out.flush();
            if (!ok) return 1;
        }
    }
    store.CheckpointIfWalExceeds(1);
    auto pinned = store.OpenReadSession(); if (!pinned) return 1;
    if (!pinned->FindEntry(*v1, {999999, 0})) return 1;
    uint64_t maxWal = 0;
    out << "],\"pinned_reader_cycles\":[";
    for (uint64_t cycle = 0; cycle < 8; ++cycle) {
        std::vector<EntryChange> changes;
        for (uint64_t index = 0; index < 8192; ++index) {
            changes.push_back({EntryChangeKind::Upsert, Row(900000 + index,
                cycle % 2 ? u"renamed_second.txt" : u"renamed_first.txt")});
        }
        if (!store.ApplyBatch(*v1, changes)) return 1;
        const auto checkpointStart = Clock::now();
        const bool checkpoint = store.CheckpointIfWalExceeds(1);
        const auto diag = store.GetCheckpointDiagnostics();
        const auto wal = Bytes(path + "-wal"); maxWal = (std::max)(maxWal, wal);
        if (cycle) out << ',';
        out << "{\"cycle\":" << cycle << ",\"checkpoint\":" << (checkpoint ? "true" : "false")
            << ",\"checkpoint_ms\":" << std::chrono::duration<double, std::milli>(Clock::now() - checkpointStart).count()
            << ",\"wal_bytes\":" << wal << ",\"private_bytes\":" << PrivateBytes()
            << ",\"busy_results\":" << diag.busyResults << '}'; out.flush();
    }
    pinned.reset();
    if (!store.CheckpointIfWalExceeds(1)) return 1;
    const auto released = store.GetCheckpointDiagnostics();
    // Reuse after disposal; checkpoint policy need not physically truncate WAL.
    const uint64_t walBeforeReuse = Bytes(path + "-wal");
    if (!store.ApplyBatch(*v1, {{EntryChangeKind::Upsert, Row(999999, u"after_reader_disposal.txt")}})) return 1;
    if (!store.CheckpointIfWalExceeds(1)) return 1;
    out << "],\"peak_observed_wal_bytes\":" << maxWal << ",\"released_log_frames\":" << released.logFrames
        << ",\"released_checkpointed_frames\":" << released.checkpointedFrames
        << ",\"wal_before_reuse\":" << walBeforeReuse << ",\"wal_after_reuse\":" << Bytes(path + "-wal")
        << ",\"private_after_cycles\":" << PrivateBytes() << ",\"completed\":true}";
    out.close(); store.Close();
    return out ? 0 : 1;
}
