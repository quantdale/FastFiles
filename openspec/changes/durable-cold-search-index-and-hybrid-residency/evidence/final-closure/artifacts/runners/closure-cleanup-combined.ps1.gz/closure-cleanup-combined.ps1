param([switch]$Execute)
$ErrorActionPreference='Stop'
$root='C:\Users\Michael Roy\Documents\FastFiles';$out=Join-Path $root 'build\closure-20261025\cleanup-combined'
$targets=@('build\worktrees\pr15-pr16-ordinary\build\release-test')
if(Get-Process -Name cl,link,ninja,cmake,ctest,FastFiles,FastFilesEngine -ErrorAction SilentlyContinue){throw 'Active build/test/product process: cleanup refused'}
$manifest=@();$preserved=@();$owners=@()
foreach($rel in $targets){
 $base=Join-Path $root $rel
 $cache=Join-Path $base 'CMakeCache.txt'
 if(!(Test-Path $cache)){throw "Not proven CMake output: $base"}
 $sourceRoot=(Select-String -LiteralPath $cache -Pattern '^CMAKE_HOME_DIRECTORY:INTERNAL=').Line.Split('=',2)[1]
 if(!$sourceRoot -or !(Test-Path (Join-Path $sourceRoot 'AGENTS.md'))){throw "Unknown ownership: $base"}
 $owners += [pscustomobject]@{path=$base;source=$sourceRoot;sourceSha=(& git -C $sourceRoot rev-parse HEAD).Trim();classification='REGENERABLE';reason='Campaign CMake compiler/linker intermediates only; all executables, fixtures, logs, configs and evidence retained'}
 $files=Get-ChildItem -LiteralPath $base -Recurse -File
 foreach($file in $files){
  if($file.Extension -in @('.obj','.pdb','.lib','.ilk','.exp','.res','.idb')){$manifest += [pscustomobject]@{path=$file.FullName;bytes=$file.Length;modified=$file.LastWriteTimeUtc}}
  elseif($file.Extension -eq '.exe'){$preserved += [pscustomobject]@{path=$file.FullName;bytes=$file.Length;sha256=(Get-FileHash -LiteralPath $file.FullName -Algorithm SHA256).Hash}}
 }
}
$owners | ConvertTo-Json | Set-Content "$out\cleanup-ownership.json"
$manifest | ConvertTo-Json | Set-Content "$out\cleanup-manifest.json"
$preserved | ConvertTo-Json | Set-Content "$out\preserved-executables.json"
$sum=($manifest|Measure-Object bytes -Sum).Sum
"PROPOSED files=$($manifest.Count) bytes=$sum"
if(!$Execute){exit 0}
$freeBefore=(Get-PSDrive C).Free
# Every candidate must be exclusively openable before ANY removal; no process is stopped.
foreach($item in $manifest){$s=[IO.File]::Open($item.path,'Open','ReadWrite','None');$s.Dispose()}
$removed=0L
foreach($item in $manifest){Remove-Item -LiteralPath $item.path -Force;$removed+=$item.bytes}
$freeAfter=(Get-PSDrive C).Free
[ordered]@{utc=[DateTime]::UtcNow;freeBefore=$freeBefore;freeAfter=$freeAfter;removedLogicalBytes=$removed;reclaimedAvailableBytes=$freeAfter-$freeBefore;files=$manifest.Count;retained='All executables, source, Git/worktrees, fixtures, unique logs/evidence, build definitions and caches';processCheck='No cl/link/ninja/cmake/ctest/FastFiles/FastFilesEngine; each removed file opened exclusively before removal'} | ConvertTo-Json | Set-Content "$out\cleanup-receipt.json"
Get-Content "$out\cleanup-receipt.json"
