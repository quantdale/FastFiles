$ErrorActionPreference='Stop'
$root='C:\Users\Michael Roy\Documents\FastFiles';$source=Join-Path $root 'build\worktrees\pr15-pr16-ordinary';$out=Join-Path $root 'build\closure-20261025\combined'
New-Item -ItemType Directory -Force $out|Out-Null
Import-Module (Join-Path $source 'verify/core/Toolchain.psm1') -Force
$tc=Find-VSToolchain;if(!$tc){throw 'No Visual Studio'};Enter-DevEnvironment -Toolchain $tc
Set-Location $source
$manifest=[ordered]@{sourceSha=(& git rev-parse HEAD).Trim();tree=(& git rev-parse 'HEAD^{tree}').Trim();toolchain=$tc;presets=@()}
foreach($preset in @('debug','release-test','debug-diagnostic')){
 if((Get-PSDrive C).Free -lt 4GB){throw "Headroom unsafe for next build: $preset"}
 & cmake --preset $preset *> "$out\configure-$preset.log";if($LASTEXITCODE){throw "configure $preset failed"}
 if($preset -eq 'debug-diagnostic'){
  & cmake --build --preset $preset --parallel 2 --target FastFiles FastFilesEngine FastFilesIndexSvc FastFilesSetup fftest *> "$out\build-$preset.log"
 }else{& cmake --build --preset $preset --parallel 2 *> "$out\build-$preset.log"}
 $buildExit=$LASTEXITCODE
 $record=[ordered]@{preset=$preset;buildExit=$buildExit;freeAfter=(Get-PSDrive C).Free}
 $manifest.presets+=$record;$manifest|ConvertTo-Json -Depth 10|Set-Content "$out\build-manifest.json"
 if($buildExit){throw "build $preset failed"}
 if($preset -ne 'debug-diagnostic'){
  & ctest --preset $preset --output-on-failure *> "$out\ctest-$preset.log"
  $record.testExit=$LASTEXITCODE;$manifest|ConvertTo-Json -Depth 10|Set-Content "$out\build-manifest.json"
  if($LASTEXITCODE){throw "ctest $preset failed"}
 }
}
Get-Content "$out\build-manifest.json"
