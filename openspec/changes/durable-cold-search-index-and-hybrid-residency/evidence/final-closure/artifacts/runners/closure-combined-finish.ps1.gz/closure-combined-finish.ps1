$ErrorActionPreference='Stop'
$root='C:\Users\Michael Roy\Documents\FastFiles';$source=Join-Path $root 'build\worktrees\pr15-pr16-ordinary';$out=Join-Path $root 'build\closure-20261025\combined'
Import-Module (Join-Path $source 'verify/core/Toolchain.psm1') -Force;$tc=Find-VSToolchain;Enter-DevEnvironment -Toolchain $tc;Set-Location $source
# Changed method after transient manifest write-open failures: complete all independent
# targets once, retaining any failed target rather than repeated stop-on-first replay.
& cmake --build --preset release-test --parallel 1 -- -k 0 *> "$out\release-keep-going.log"
$buildExit=$LASTEXITCODE
& ctest --preset release-test --output-on-failure *> "$out\ctest-release-test.log"
$testExit=$LASTEXITCODE
if((Get-PSDrive C).Free -lt 3GB){throw 'Diagnostic build reserve unavailable'}
& cmake --preset debug-diagnostic *> "$out\configure-debug-diagnostic.log";if($LASTEXITCODE){throw 'diag configure'}
& cmake --build --preset debug-diagnostic --parallel 1 --target FastFiles FastFilesEngine FastFilesIndexSvc FastFilesSetup fftest *> "$out\build-debug-diagnostic.log"
$diagExit=$LASTEXITCODE
[ordered]@{sourceSha=(& git rev-parse HEAD).Trim();tree=(& git rev-parse 'HEAD^{tree}').Trim();releaseKeepGoingBuildExit=$buildExit;releaseCtestExit=$testExit;diagnosticApplicationBuildExit=$diagExit;freeAfter=(Get-PSDrive C).Free;limitations='EarlierC1041 and LNK1104 retained; no compiler/security options changed; no manual process termination'}|ConvertTo-Json|Set-Content "$out\completion.json"
Get-Content "$out\completion.json"
if($diagExit){exit 1}
