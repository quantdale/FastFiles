$ErrorActionPreference='Stop'
$root='C:\Users\Michael Roy\Documents\FastFiles';$repo=Join-Path $root 'build\worktrees\pr15-pr16-ordinary';$out=Join-Path $root 'build\closure-20261025\combined';Set-Location $repo
& pwsh -NoProfile -File verify/e2e/Run-FastFilesE2E.ps1 -ArtifactsDir "$out\e2e" -RequireExactTree *> "$out\e2e.log"
$e2e=$LASTEXITCODE
foreach($scenario in @('core-smoke','visual-matrix')){
 & pwsh -NoProfile -File verify/certification/Invoke-UiaLongRunCertification.ps1 -Preset debug-diagnostic -Scenario $scenario -Iterations 25 -RequireExactTree -OutputPath "$out\uia-$scenario.json" -MarkdownOutputPath "$out\uia-$scenario.md" *> "$out\uia-$scenario.log"
 if($LASTEXITCODE){throw "UIA $scenario incomplete/failing"}
}
Import-Module (Join-Path $repo 'verify/capabilities/windows-ui-automation-validation/UiAutomationValidation.psm1') -Force -DisableNameChecking
$result=Invoke-UiAutomationValidationCapability -RunContext @{} -Fingerprint @{} -ArtifactsDir "$out\uia-full" -Options @{RepoRoot=$repo;UiaExeRel='build/debug-diagnostic/src/ui/FastFiles.exe';InvocationId='closure-three-pr-final'}
$result|ConvertTo-Json -Depth 30|Set-Content "$out\uia-full.json"
[ordered]@{sourceSha=(& git rev-parse HEAD).Trim();tree=(& git rev-parse 'HEAD^{tree}').Trim();e2eExit=$e2e;uiaFullStatus=$result.Status;uiaFullSummary=$result.Summary}|ConvertTo-Json|Set-Content "$out\runtime-summary.json"
Get-Content "$out\runtime-summary.json"
if($e2e -ne 0 -or $result.Status -eq 'FAIL'){exit 1}
