$ErrorActionPreference='Stop';$root='C:\Users\Michael Roy\Documents\FastFiles';$repo=Join-Path $root 'build\worktrees\pr15-pr16-ordinary';$out=Join-Path $root 'build\closure-20261025\combined';Import-Module (Join-Path $repo 'verify/core/Toolchain.psm1') -Force;$tc=Find-VSToolchain;Enter-DevEnvironment -Toolchain $tc;Set-Location $repo
if((Get-PSDrive C).Free -lt 4GB){throw 'Analyze budget refused'}
& cmake --preset analyze *> "$out\configure-analyze.log";if($LASTEXITCODE){exit $LASTEXITCODE}
& cmake --build --preset analyze --parallel 1 -- -k 0 *> "$out\build-analyze.log";$analyze=$LASTEXITCODE
if((Get-PSDrive C).Free -lt 2GB){throw 'ASan reserve refused'}
& cmake --preset asan *> "$out\configure-asan.log";if($LASTEXITCODE){exit $LASTEXITCODE}
& cmake --build --preset asan --parallel 1 --target ffprotocol_fuzz_tests ffipc_framing_tests ffipc_listener_lifecycle_tests ffvolumescanner_terminal_tests *> "$out\build-asan.log";$asanBuild=$LASTEXITCODE
& ctest --test-dir build/asan -R '^(ffprotocol_fuzz_tests|ffipc_framing_tests|ffipc_listener_lifecycle_tests|ffvolumescanner_terminal_tests)$' --output-on-failure *> "$out\ctest-asan.log";$asanTest=$LASTEXITCODE
& pwsh -NoProfile -File verify/Invoke-OpenSpecStrict.ps1 -RepoRoot $repo *> "$out\strict-openspec.log";$spec=$LASTEXITCODE
[ordered]@{sourceSha=(& git rev-parse HEAD).Trim();analyzeExit=$analyze;asanBuildExit=$asanBuild;asanTestExit=$asanTest;strictSpecExit=$spec;freeAfter=(Get-PSDrive C).Free}|ConvertTo-Json|Set-Content "$out\static-summary.json"
Get-Content "$out\static-summary.json"
if($analyze -or $asanBuild -or $asanTest -or $spec){exit 1}
