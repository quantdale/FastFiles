$ErrorActionPreference='Stop'
$root='C:\Users\Michael Roy\Documents\FastFiles';$source=Join-Path $root 'build\worktrees\durable-cold-search';$out=Join-Path $root 'build\closure-20261025';$scratch=Join-Path $out 'scratch-5m'
$exe=Join-Path $source 'build\release-test\tests\engine\ffengine_bench_ingestion_uninstrumented.exe'
$hash=(Get-FileHash -LiteralPath $exe -Algorithm SHA256).Hash.ToLowerInvariant()
if($hash -ne '52fe83b9aaecfd113ec68af134c8e826e86ffc52d549e8bcfc4bbe61453f997d'){throw 'Unexpected benchmark executable'}
$free=(Get-PSDrive C).Free
# Historical partial pipeline WAL 2.878GB at3.6M; allow4.5GiB WAL +2GiB DB,
# 3GiB OS/host reserve and128MiB retained outputs. No scratch copies/builds in parallel.
$budget= [ordered]@{database=2GB;wal=4608MB;scratchCopies=0;osAndHostReserve=3GB;retainedArtifacts=128MB;concurrentBuilds=0}
$required=($budget.Values|Measure-Object -Sum).Sum
$preflight=[ordered]@{experiment='closure-final-allocator-free-5m';utc=[DateTime]::UtcNow;implementation_sha='4c1c4501e5b1f0579a2d34f4f7afea5f83708979';executed_source_sha='269d1c36036cb84b40c3ef01baee3c2b6c990579';repository_tip=(& git -C $source rev-parse HEAD).Trim();executable=$exe;executable_sha256=$hash;fixture='BuildSyntheticDatabase deterministic v1; no random seed;5000000 rows;8192 batch;production FTS and500MiB/400MiB policy';targetVolume='C: NTFS Acer; D is not independent';freeBytes=$free;budgetBytes=$budget;requiredBytes=$required;storage='Existing local NTFS system volume; physical medium not independently established';acceptance='Actual5M completion; pre/post3.1M progress; peak process memory and observed WAL; no probe allocator';cleanup='Benchmark removes its exact owned fixture after close; logs/JSON retained; no process termination';status= $(if($free -ge $required){'PREFLIGHT_PASS'}else{'REFUSED'})}
$preflight | ConvertTo-Json -Depth 8 | Set-Content "$out\ingestion-preflight.json"
if($free -lt $required){throw "Headroom refusal: free=$free required=$required"}
if(Get-Process -Name cl,link,ninja,ctest,ffengine_bench_large_index_scalability,ffengine_bench_ingestion_uninstrumented -ErrorAction SilentlyContinue){throw 'Competing build/workload'}
New-Item -ItemType Directory -Force $scratch|Out-Null
$env:TEMP=$scratch;$env:TMP=$scratch
$args=@('--scales','5000000','--output',('"'+$out+'\ingestion-5m.json"'),'--source-sha','269d1c36036cb84b40c3ef01baee3c2b6c990579','--source-state','clean','--preset','release-test')
$p=Start-Process -FilePath $exe -ArgumentList $args -WorkingDirectory $source -PassThru -RedirectStandardOutput "$out\ingestion-5m.log" -RedirectStandardError "$out\ingestion-5m.err"
$timer=[Diagnostics.Stopwatch]::StartNew();$samples=[Collections.Generic.List[object]]::new()
while(!$p.HasExited){
 $p.Refresh();$files=Get-ChildItem -LiteralPath $scratch -Recurse -File -ErrorAction SilentlyContinue
 $db=($files|Where-Object Name -eq 'index.db'|Measure-Object Length -Sum).Sum
 $wal=($files|Where-Object Name -eq 'index.db-wal'|Measure-Object Length -Sum).Sum
 $samples.Add([pscustomobject]@{seconds=$timer.Elapsed.TotalSeconds;privateBytes=$p.PrivateMemorySize64;workingSet=$p.WorkingSet64;cpuSeconds=$p.TotalProcessorTime.TotalSeconds;databaseBytes=$db;walBytes=$wal;freeBytes=(Get-PSDrive C).Free})
 Start-Sleep -Milliseconds 250
}
$p.WaitForExit();$samples|ConvertTo-Json|Set-Content "$out\ingestion-samples.json"
[ordered]@{exitCode=$p.ExitCode;elapsedSeconds=$timer.Elapsed.TotalSeconds;sampleCount=$samples.Count;peakObservedWal=($samples|Measure-Object walBytes -Maximum).Maximum;peakObservedDb=($samples|Measure-Object databaseBytes -Maximum).Maximum;minimumFree=($samples|Measure-Object freeBytes -Minimum).Minimum;freeAfter=(Get-PSDrive C).Free;remainingScratchFiles=@(Get-ChildItem -LiteralPath $scratch -Recurse -File).Count} | ConvertTo-Json | Set-Content "$out\ingestion-runner.json"
Get-Content "$out\ingestion-runner.json"
if($p.ExitCode -ne 0){throw 'Benchmark failed; preserve all files'}
Get-Content "$out\ingestion-5m.json"
