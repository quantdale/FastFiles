$ErrorActionPreference='Stop'
$root='C:\Users\Michael Roy\Documents\FastFiles'
$out=Join-Path $root 'build\closure-20261025'
New-Item -ItemType Directory -Force $out | Out-Null
Get-CimInstance Win32_LogicalDisk | Select-Object DeviceID,DriveType,FileSystem,Size,FreeSpace | ConvertTo-Json | Set-Content "$out\volumes.json"
Get-Volume | Select-Object DriveLetter,FileSystemLabel,UniqueId,Path,Size,SizeRemaining | ConvertTo-Json | Set-Content "$out\volume-identities.json"
$processes=Get-CimInstance Win32_Process
$processes | Where-Object {$_.Name -match 'FastFiles|bench|ninja|cmake|ctest|cl.exe|link.exe|node|pwsh|python'} | Select-Object ProcessId,ParentProcessId,Name,ExecutablePath,CreationDate | ConvertTo-Json | Set-Content "$out\processes.json"
# Inventory only build roots; skip all source, Git, verification run/signing trees and links.
$roots=@('build','build\worktrees\durable-cold-search\build','build\worktrees\f9-toggle-fix\build','build\worktrees\pr15-pr16-ordinary\build')
$rows=@(); $large=@()
foreach($relative in $roots){
 $base=Join-Path $root $relative
 foreach($dir in Get-ChildItem -LiteralPath $base -Directory){
  if($dir.Name -in @('worktrees','equiv-matrix','.git')){continue}
  $stack=[System.Collections.Generic.Stack[string]]::new();$stack.Push($dir.FullName); [long]$bytes=0;[long]$count=0
  while($stack.Count){
   foreach($item in Get-ChildItem -LiteralPath $stack.Pop() -Force -ErrorAction SilentlyContinue){
    if($item.Attributes -band [IO.FileAttributes]::ReparsePoint){continue}
    if($item.PSIsContainer){if($item.Name -notin @('.git','.signing','runs','baselines')){$stack.Push($item.FullName)}}
    else{$bytes+=$item.Length;$count++;if($item.Length -gt 100MB){$large += [pscustomobject]@{path=$item.FullName;bytes=$item.Length;modified=$item.LastWriteTimeUtc}}}
   }
  }
  $rows += [pscustomobject]@{path=$dir.FullName;bytes=$bytes;files=$count}
 }
}
$rows | Sort-Object bytes -Descending | ConvertTo-Json | Set-Content "$out\directory-sizes.json"
$large | Sort-Object bytes -Descending | ConvertTo-Json | Set-Content "$out\large-files.json"
$rows | Sort-Object bytes -Descending | Format-Table -AutoSize
Get-Content "$out\volume-identities.json"
