$ErrorActionPreference='Stop'
$root='C:\Users\Michael Roy\Documents\FastFiles';$repo=Join-Path $root 'build\worktrees\durable-cold-search';$out=Join-Path $root 'build\closure-20261025';$scratch=Join-Path $out 'operational-scratch';New-Item -ItemType Directory -Force $scratch|Out-Null
Import-Module (Join-Path $repo 'verify/core/Toolchain.psm1') -Force;$tc=Find-VSToolchain;Enter-DevEnvironment -Toolchain $tc
$source=Join-Path $out 'operational_matrix.cpp';$lib=Join-Path $repo 'build/release-test/src/indexstore/ffindexstore.lib';$sqlite=Join-Path $repo 'build/release-test/third_party/sqlite/sqlite3.lib';$exe=Join-Path $out 'operational_matrix.exe'
& cl.exe /nologo /std:c++20 /EHsc /O2 /MD /W4 /WX /permissive- /sdl /guard:cf /DNOMINMAX ("/I"+(Join-Path $repo 'src/indexstore/include')) $source ("/Fo"+(Join-Path $out 'operational_matrix.obj')) ("/Fe"+$exe) /link $lib $sqlite kernel32.lib psapi.lib /DYNAMICBASE /NXCOMPAT /guard:cf *> "$out\operational-build.log"
if($LASTEXITCODE){throw 'Operational harness build failed'}
$binding=[ordered]@{experiment='closure-2m-multivolume-cap-and-reader';productionSource='db7887c1ec1d3d8f493848a9050240407423e678';harnessSha256=(Get-FileHash $source).Hash;storeLibrarySha256=(Get-FileHash $lib).Hash;sqliteLibrarySha256=(Get-FileHash $sqlite).Hash;exeSha256=(Get-FileHash $exe).Hash;freeBefore=(Get-PSDrive C).Free;budget=@{database=1GB;wal=2GB;copies=0;osReserve=3GB;outputs=128MB};scope='Actual production Store candidate/admission/read-session/checkpoint APIs;2x1M volumes;3 cycles of6cells;8pinned-reader write/checkpoint cycles;not complete engine SearchIndexed response comparator or universal WAL bound'}
$binding|ConvertTo-Json -Depth 8|Set-Content "$out\operational-preflight.json"
if($binding.freeBefore -lt 6272MB){throw 'Operational resource preflight refusal'}
& $exe (Join-Path $scratch 'index.db') (Join-Path $out 'operational-matrix.json') *> "$out\operational-run.log"
$binding.exitCode=$LASTEXITCODE;$binding.freeAfter=(Get-PSDrive C).Free;$binding|ConvertTo-Json -Depth 8|Set-Content "$out\operational-binding.json"
Get-Content "$out\operational-binding.json"
if($binding.exitCode){throw 'Operational matrix failed; preserve fixture'}
