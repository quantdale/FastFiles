$ErrorActionPreference='Stop'
$root='C:\Users\Michael Roy\Documents\FastFiles';$repo=Join-Path $root 'build\worktrees\durable-cold-search';$out=Join-Path $root 'build\closure-20261025\final-oracle';New-Item -ItemType Directory -Force $out|Out-Null;Set-Location $repo
$exe=Join-Path $repo 'build/release-test/tests/engine/ffengine_bench_identity_ordering_oracle.exe'
$binding=[ordered]@{sourceSha='db7887c1ec1d3d8f493848a9050240407423e678';exeSha256=(Get-FileHash $exe -Algorithm SHA256).Hash;scope='Read-only extended5M cold-index vs independent full-canonical; not hot5M';runs=@()}
$db=Join-Path $repo 'build/campaign/open-5m.db';$before=(Get-FileHash $db -Algorithm SHA256).Hash
& $exe --db $db --readonly-fixture --extended --output "$out\oracle-5m-extended.json" *> "$out\oracle-5m-extended.log"
$exit=$LASTEXITCODE;$after=(Get-FileHash $db -Algorithm SHA256).Hash
$binding.runs+=@{rows=5000000;sourceFixture=$db;beforeHash=$before;afterHash=$after;unchanged=($before -eq $after);exitCode=$exit}
$binding|ConvertTo-Json -Depth 8|Set-Content "$out\binding.json"
Get-Content "$out\binding.json"
if($exit -ne 0 -or $before -ne $after){exit 1}
