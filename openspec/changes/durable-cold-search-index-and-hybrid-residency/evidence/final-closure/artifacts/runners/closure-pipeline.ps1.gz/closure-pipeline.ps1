$ErrorActionPreference='Stop'
$root='C:\Users\Michael Roy\Documents\FastFiles';$source=Join-Path $root 'build\worktrees\durable-cold-search';$out=Join-Path $root 'build\closure-20261025';$scratch=Join-Path $out 'scratch-pipeline'
$exe=Join-Path $source 'build\release-test\tests\engine\ffengine_bench_large_index_scalability.exe'
$binding=[ordered]@{experiment='closure-final-2m-same-pipeline';source_sha='269d1c36036cb84b40c3ef01baee3c2b6c990579';implementation_sha='4c1c4501e5b1f0579a2d34f4f7afea5f83708979';exeSha256=(Get-FileHash $exe -Algorithm SHA256).Hash;fixture='Same deterministic production BuildSyntheticDatabase v1 pipeline as historical scalability harness;8192 batches';target='C: NTFS';free=(Get-PSDrive C).Free;databaseBudget=1GB;walBudget=2GB;scratchCopies=0;osReserve=3GB;outputBudget=128MB;allocatorProbeEnabled=$true;acceptance='Two fresh-process2M matrices, all12 established classes, default budget cold transition; historical-compatible boundary, not Store fixture or OS-cache-flushed';cleanup='Harness removes each owned scratch database after completion';runs=@()}
if($binding.free -lt 6272MB){throw 'Insufficient capacity for 2M'}
New-Item -ItemType Directory -Force $scratch|Out-Null;$env:TEMP=$scratch;$env:TMP=$scratch
$binding|ConvertTo-Json -Depth 8|Set-Content "$out\pipeline-preflight.json"
Set-Location $source
foreach($i in 1..2){
 if((Get-PSDrive C).Free -lt 6272MB){throw 'Capacity changed: refuse next run'}
 $timer=[Diagnostics.Stopwatch]::StartNew()
 & $exe --scales 2000000 --output "$out\pipeline-2m-$i.json" --source-sha 269d1c36036cb84b40c3ef01baee3c2b6c990579 --source-state clean --preset release-test --diagnostics *> "$out\pipeline-2m-$i.log"
 $exit=$LASTEXITCODE
 $binding.runs += [ordered]@{iteration=$i;exitCode=$exit;wallSeconds=$timer.Elapsed.TotalSeconds;freeAfter=(Get-PSDrive C).Free}
 $binding|ConvertTo-Json -Depth 8|Set-Content "$out\pipeline-runner.json"
 if($exit -ne 0){throw "Pipeline run$i failed"}
}
Get-Content "$out\pipeline-runner.json"
