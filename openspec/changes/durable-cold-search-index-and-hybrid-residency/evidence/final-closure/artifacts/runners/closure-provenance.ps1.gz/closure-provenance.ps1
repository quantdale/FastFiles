$ErrorActionPreference='Stop'
$root='C:\Users\Michael Roy\Documents\FastFiles';$pr15=Join-Path $root 'build/worktrees/durable-cold-search';$combined=Join-Path $root 'build/worktrees/pr15-pr16-ordinary';$dest=Join-Path $pr15 'openspec/changes/durable-cold-search-index-and-hybrid-residency/evidence/final-closure'
$binaryRows=@()
foreach($item in @(@{name='pr15';root=$pr15;sha='db7887c1ec1d3d8f493848a9050240407423e678'},@{name='combined';root=$combined;sha='e5b006dc9255931a41ff8fa135198f688d093434'})){
 foreach($preset in @('debug','release-test','debug-diagnostic','analyze','asan')){
  if($item.name -eq 'pr15' -and $preset -eq 'debug-diagnostic'){continue}
  foreach($part in @('src','tests')){
   $dir=Join-Path $item.root "build/$preset/$part";if(!(Test-Path $dir)){continue}
   foreach($file in Get-ChildItem -LiteralPath $dir -Recurse -File -Filter '*.exe'){
    if($preset -eq 'asan' -and $file.BaseName -notin @('ffprotocol_fuzz_tests','ffipc_framing_tests','ffipc_listener_lifecycle_tests','ffvolumescanner_terminal_tests')){continue}
    $binaryRows += [ordered]@{candidate=$item.name;preset=$preset;executedSourceSha=$item.sha;path=[IO.Path]::GetRelativePath($item.root,$file.FullName).Replace('\','/');bytes=$file.Length;sha256=(Get-FileHash $file.FullName -Algorithm SHA256).Hash.ToLowerInvariant();role=$(if($file.Name -match 'bench|oracle'){'benchmark'}elseif($part -eq 'src'){'product'}else{'test'})}
   }
  }
 }
}
Import-Module (Join-Path $pr15 'verify/core/Toolchain.psm1') -Force;$tc=Find-VSToolchain
[ordered]@{schema='fastfiles-final-closure-provenance-v1';implementation_sha='db7887c1ec1d3d8f493848a9050240407423e678';executed_source_sha='db7887c1ec1d3d8f493848a9050240407423e678';starting_repository_tip='2ff3b595940d95c706fa815b72ffee1c8d53fb44';combined_source_sha='e5b006dc9255931a41ff8fa135198f688d093434';combined_tree_sha='2069796b1dbd10cdd5d3558f73d30d2e1b29116e';pr14='d3884eecd03805a91fe5d12d7a90ceb1b5c082f2';pr16='e75a230db9ac89f6a638754cb6ad672735e4d644';main_at_simulation='a26fe609439a18c128b2a2e557bc7eb2534fa128';evidence_sha='derive repository tip externally after evidence commit; not self-referential';repository_tip_sha='derive live externally';toolchain=$tc;compiler_msc_full_ver=194435228;fixture5m_sha256='96d353521e2154ce7a60cadaf7fadd70b6494e536aa83e14e023b304862ecb03';binaryHashes=$binaryRows;limitations=@('Hashes bind actual available binaries; not bit-for-bit reproducibility','PR15 diagnostic binaries were not rebuilt after subtree repair and are historical; combined diagnostic e5b006dc is the current runtime certification candidate','ASan covers four named protocol/IPC/scanner tests only, not all projection code','Standalone operational harness/library hashes in artifacts/operational-binding.json.gz; no allocator probes; its evidence-only source is explicitly outside product CMake input closure')}|ConvertTo-Json -Depth 12|Set-Content (Join-Path $dest 'provenance-manifest.json') -Encoding utf8NoBOM
"Binary hash rows=$($binaryRows.Count)"
