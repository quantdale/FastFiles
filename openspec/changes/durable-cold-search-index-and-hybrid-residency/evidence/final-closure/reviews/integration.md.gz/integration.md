Now I have all the evidence. Let me compile the complete final review artifact.

---

## Review

### Review Scope and Targets
- **PR15 HEAD (review target):** `2ff3b595940d95c706fa815b72ffee1c8d53fb44` (`feat/durable-cold-search-and-hybrid-residency` @ `b68767a`)
- **Executable implementation:** `4c1c4501e5b1f0579a2d34f4f7afea5f83708979`
- **Clean executed source:** `269d1c36036cb84b40c3ef01baee3c2b6c990579` (identical executable/test/benchmark inputs)
- **PR14 base:** `d3884eecd03805a91fe5d12d7a90ceb1b5c082f2` (clean, untouched)
- **PR16:** `e75a230db9ac89f6a638754cb6ad672735e4d644` (based on `origin/main` `a26fe609`, separate UI fix)
- **Combined candidate:** `6d3de0e8c9242315bad004cefc685f8f2f75b2b9` (tree `6ecbca7586b8044bc11ec1b389f41e0fa4149d6e`, branch `validation/pr15-pr16-ordinary-20261024`)
- **OpenSpec change:** `durable-cold-search-index-and-hybrid-residency` (lifecycle `active`)
- **Key open tasks:** 4.1, 4.2, 5.7, 5.10, 5.12, 5.14 — all `[ ]` unchecked

---

### Correct: What Is Already Good (with Evidence)

| Item | Evidence |
|------|----------|
| **PR15 product tree unchanged since `628de6d`** | `git diff 628de6d..b68767a -- src/ tests/` empty per `bench-identity-reconciliation.md:8,15`; only docs/evidence/tasks delta |
| **PR16 source fix is minimal and correct** | Gallery review: `ThemeToggle.h` resolves `FollowSystem` at press time; `NextThemeTogglePreference` inverts rendered theme for all states; `fftheme_toggle_tests` covers all 6 transitions (light/dark/FollowSystem × system light/dark) |
| **PR15 does not cause Gallery failures** | Controlled A/B: `git diff d3884ee..b68767a -- verify/visual src/ui` empty; both arms fail `gallery-dark/narrow/wide` identically 2/2; root cause traced to `WindowShell.cpp:2921-2926` F9 handler mapping `FollowSystem→Light` (no-op on light systems) — predates PR15 |
| **Combined source equality (UI/protocol/search/ipc/setup)** | `git diff e75a230..6d3de0e -- src/ui src/search src/protocol src/ipc src/setup` empty per `current-combined-focused.json:6` and `checkpoint-3a41481/combined-focused.json:6` |
| **Combined focused tests pass** | Debug 3/3, release-test 3/3 at `6d3de0e` per `current-combined-focused.json` and `checkpoint-3a41481/combined-focused.json` |
| **PR15 local certification ladder passes** | Debug 130/130, release-test 130/130, Analyze clean, ASan 4/4, strict OpenSpec/governance/hygiene, canonical parity 11/11, E2E 8/8, UIA core 25/25, visual matrix 25/25, full UIA 23PASS/5SKIP/0FAIL at clean `269d1c3` per `final-current/README.md` |
| **Ordinary error matrix passes** | `ffengine_storage_pressure_tests --ordinary-only` passes: pinned/overlapping readers, BUSY/backfill, simulated `SQLITE_FULL` across 8 ops, second-chunk error with committed-prefix retention, interrupted readiness repair, version-read refusal, failed reconciliation enumeration retention per `deferred-ordinary-acceptance.md` and `ordinary-recovery-owner-report.md:C` |
| **Read-only 2M/5M oracle passes** | 2M: 13/13 ×3 fresh processes; 5M: 13/13 cold/canonical oracle; candidate routes, zero hot rows, full canonical counts asserted, fixture hashes unchanged per `identities.json` and `current-readonly-runner.json` |
| **Allocator-free ingestion preflight binding verified** | Link maps resolve `new`/`delete` to CRT (not probe); executable SHA256 `52fe83b9...` bound per `identities.json`; 200k/1M stages at `dab2128` per `ordinary-recovery-owner-report.md:D` |

---

### Finding: P0 — Open Acceptance Gates Block Merge

| Task | Status | Location | Evidence | Smallest Fix |
|------|--------|----------|----------|--------------|
| **4.1: Complete governing exact hot/cold equivalence at 200k/1M/2M/5M** | `[ ]` UNCHECKED | `tasks.md:46` | Only capped cold-vs-canonical at 2M (13/13×3) and 5M (13/13×1) verified. **No fully-hot 5M**, no dedicated targeted/uncapped 5M equivalence. v1 oracle withdrawn. Spec requires identity/order match at all scales hot vs cold-with-index. | Owner must provision disk headroom (≥8 GiB planned) and execute full hot/cold matrix at 5M including targeted/uncapped cells. Cannot be narrowed post-hoc. |
| **4.2: Resource/operational acceptance qualified** | `[ ]` UNCHECKED | `tasks.md:47` | Default 500MiB/400MiB estimator policy unchanged (not RSS bound). Full 5M ingestion/large-WAL cells disk-blocked; deliberate termination cells NOT_EXECUTED. No universal WAL/reserve bound claimed. Current free ~1 GiB insufficient. | Provision safe scratch capacity; run missing 5M ingestion, large pinned-reader WAL growth, and deliberate termination cells under a separate permitted validation plan. |
| **5.7: Final-source query measurements at clean `269d1c3`** | `[ ]` UNCHECKED | `tasks.md:35` | 2M read-only Store-fixture matrices 13/13×3 and 5M oracle 13/13 executed. **Same-pipeline-harness 2M repeat matrix, multi-volume selective, candidate-cap performance boundaries NOT_EXECUTED** (disk capacity). Allocator-free 5M ingestion preflight rejected at 966 MB free (exit 3, zero rows). | Provision disk headroom; run missing performance cells and allocator-free 5M ingestion. Earlier `dab2128` 200k/1M stages are commit-bound, not `4c1c450` timings. |
| **5.10: Independent adversarial review of final `4c1c450` source** | `[ ]` BLOCKED_EXTERNAL | `tasks.md:38,53` | Five initial lanes at `8c4c848`; projection re-review approved. **Final data/performance follow-ups at `dab2128` failed with `Codex error: The usage limit has been reached` — no verdicts.** Fixed-route `opencode/hy3-free` preflight also failed (native Kimi unavailable). No fallback, no retry, no self-review mislabeled as independent. | Owner must restore reviewer availability; inspect final `4c1c450` source and latest harness, not pre-fix summaries. |
| **5.14: Final review of acceptance fixes** | `[ ]` BLOCKED_EXTERNAL | `tasks.md:53` | Same as 5.10 — final follow-up reviews never completed. Latest Store/manager composition fixes have ordinary passing tests only, not final independent approval. | Same as 5.10. |

**Merge Impact:** All six are **merge-blocking** per OpenSpec governance — unchecked `[ ]` counts in `tasks.md` are raw acceptance truth. No task is silently narrowed or reclassified.

---

### Finding: P1 — Combined Runtime Qualification Not Executed (Task 5.12)

| Issue | Location | Evidence |
|-------|----------|----------|
| **Full combined PR15+PR16 application builds, Gallery, and UIA NOT_EXECUTED** | `tasks.md:42`, `deferred-ordinary-acceptance.md:16`, `current-combined-focused.json:4` | Only focused Debug/release-test 3/3 each pass. Source equality for UI/protocol/search/ipc/setup confirmed, but **no combined runtime Gallery/UIA execution**. Combined candidate `6d3de0e` is a local validation branch only, not pushed/merged. |
| **Gallery disposition unresolved** | `tasks.md:42`, `deferred-ordinary-acceptance.md:16` | PR15 catalog 17/20 (3 FAIL inherited); PR16 standalone catalog 20/20. **Owner decision required**: integrate PR16 fix, explicitly exclude Gallery from PR15 acceptance, or defer. Independent source compatibility alone does not close 5.12. |

**Smallest Fix:** Owner must decide Gallery integration/dependency or governance-valid exclusion. Provision disk headroom for combined runtime qualification if integrating.

---

### Finding: P1 — Hot/Cold Contract Ambiguity Requires Owner Clarification

| Issue | Location | Evidence |
|-------|----------|----------|
| **Spec requires "Cold-with-index results shall equal hot results" at 200k/1M/2M/5M for ALL query classes** | `specs/index-engine/spec.md` Requirement "Cold-with-index results shall equal hot results", Scenario "Differential identity across scales" | Current evidence: capped cold-vs-canonical at 2M/5M only. **No hot 5M execution**, no hot 2M multi-volume/candidate-cap boundary measurements. The "hot path" at 5M is the projection path (which exceeds 500 MiB budget and falls back to cold) — the spec's hot/cold equivalence at 5M is **not measurable as stated** because the projection budget strands 5M in cold regime by design. |
| **Task 4.1 acceptance cannot be satisfied without contract clarification** | `tasks.md:46` | "NOT fully-hot5M or dedicated targeted/uncapped5M equivalence; no silent narrowing of the spec." The 500 MiB default budget is explicitly unchanged (Requirement: "The durable index shall not raise the default memory budget"). At 5M rows, the projection exceeds budget → cold path serves all queries. Hot/cold equivalence at 5M is vacuously true (both cold) or undefined (hot path unavailable). |

**Proposed Contract Clarification (Owner Required — Do Not Edit Governing Specs):**
> The hot/cold equivalence requirement at 5M rows **must be explicitly scoped** to either:
> 1. **Cold-with-index vs. canonical cold scan** (current measurable oracle), with hot-path equivalence required only at scales where the projection budget admits the hot path (≤2M at 500 MiB default), OR
> 2. **Hot-path equivalence at 5M** requires a measured safety case for raising the default budget (separate change), OR
> 3. **Hot/cold equivalence at 5M is waived** with documented rationale (projection budget straddle is a known product constraint).
>
> **This clarification must come from the product owner** — the current spec text is unambiguous but physically unrealizable under the unchanged 500 MiB default. No agent may silently narrow the spec to make a checkbox green.

---

### Finding: P2 — Evidence Provenance and Identity Gaps

| Issue | Location | Evidence |
|-------|----------|----------|
| **5M migration artifact produced by dirty-harness binary** | `lane-E-spec-provenance.md:77,84,86` | `5m-migration-v2.json` identity: `source_sha "628de6d+dirty-harness"`, `build_identity "628de6d"` — executable matches **no committed tree** (uncommitted `bench_store_open.cpp` delta). `b68767a` final tip postdates documented chain; equivalence gate "to the final tip" (`certification-record.md:6-8`) must be confirmed to cover `b68767a`, not just `80a6f11`. |
| **Certification record claims "fail-closed downgrade PASS" with no backing test** | `lane-E-spec-provenance.md:70,91` | P1 finding: `certification-record.md:51` PASS claim unbacked by any test/artifact; Task 3.3c's "downgrade-policy evidence" does not exist. Downgrade refusal test (`TestNewerSchemaVersionFailsClosedWithoutDataLoss`) not added. |
| **Open-matrix 200k–2M cells cite dirty pre-remediation tree** | `lane-E-spec-provenance.md:86` | Cells at `628de6d` (clean) but `b68767a` delta unknown — `git diff 80a6f11..b68767a` touches only docs/evidence/tasks per `bench-identity-reconciliation.md:9`, but unverified without shell. |
| **Executable-tree equivalence gate not run at final `b68767a`** | `lane-E-spec-provenance.md:78,87` | Gate from `628de6d` to "final tip" (`certification-record.md:6-8`) — ambiguity whether "final tip" = `80a6f11` or `b68767a`. Must be re-run at actual final evidence HEAD. |

**Smallest Fix:** Rebuild `ffindexstore_bench_store_open` at clean tip; re-run 5M migration measurement; add downgrade refusal test; run executable-tree equivalence gate `Test-ExecutableTreeEquivalence.ps1 -ImplementationSha 4c1c4501e5b1f0579a2d34f4f7afea5f83708979 -EvidenceSha <final-evidence-tip>` after evidence commit.

---

### Finding: P2 — Hosted Certification Not Obtained

| Issue | Location | Evidence |
|-------|----------|----------|
| **Hosted CI externally blocked** | `deferred-ordinary-acceptance.md:16`, `ordinary-recovery-owner-report.md:G` | Prior runs (e.g., `39972399750`) six jobs, zero steps, billing/spending-limit annotation. Local parity 11/11 passes, but **`HOSTED_CERTIFICATION = NOT_OBTAINED`**. No billing/policy changes by agent. | Owner must restore GitHub Actions infrastructure; inspect final pushed SHA once. Local parity ≠ hosted certification. |

---

### Finding: P2 — LSP/Static Analysis Not Globally Clean

| Issue | Location | Evidence |
|-------|----------|----------|
| **Standalone LSP include-context findings and timeouts remain** | `final-current/README.md`, `ordinary-recovery-owner-report.md:F` | "LSP sweep is not globally clean: standalone include-context findings and two timeouts remain; MSVC C++20/W4/WX and Analyze are the authoritative passing checks." | No action required — MSVC `/analyze` clean is the gate. Documented for transparency. |

---

### Merge Verdict: **BLOCK**

**Rationale:** Six OpenSpec acceptance tasks (4.1, 4.2, 5.7, 5.10, 5.12, 5.14) remain `[ ]` unchecked with concrete evidence gaps. Tasks 5.10 and 5.14 are `BLOCKED_EXTERNAL` (reviewer availability). Tasks 4.1, 4.2, 5.7, 5.12 require disk headroom and owner decisions (Gallery integration, hot/cold contract clarification at 5M). No merge, force-push, or release authorization is possible until:
1. Owner provisions ≥8 GiB safe scratch and runs missing 5M cells (4.1, 4.2, 5.7)
2. Owner clarifies hot/cold contract at 5M under unchanged 500 MiB budget (4.1)
3. Owner decides Gallery integration/dependency/exclusion (5.12)
4. Independent reviewer availability restored; final `4c1c450` source reviewed (5.10, 5.14)
5. Downgrade refusal test added; 5M migration re-measured at clean tip; executable-tree equivalence gate run at final evidence HEAD
6. Hosted CI infrastructure restored; final pushed SHA inspected once

**No silent narrowing of spec, no reclassification of NOT_EXECUTED cells as PASS, no inheritance of pre-fix review verdicts.** The campaign remains `active` in `openspec/lifecycle.json` with these tasks open — this is the authoritative state.

---

### Reviewed SHA, Scope, Limitations

| Field | Value |
|-------|-------|
| **Reviewed SHA (PR15 HEAD)** | `2ff3b595940d95c706fa815b72ffee1c8d53fb44` (`b68767a`) |
| **Executable implementation SHA** | `4c1c4501e5b1f0579a2d34f4f7afea5f83708979` |
| **Clean executed source SHA** | `269d1c36036cb84b40c3ef01baee3c2b6c990579` |
| **PR14 base** | `d3884eecd03805a91fe5d12d7a90ceb1b5c082f2` |
| **PR16** | `e75a230db9ac89f6a638754cb6ad672735e4d644` |
| **Combined candidate** | `6d3de0e8c9242315bad004cefc685f8f2f75b2b9` (tree `6ecbca7586b8044bc11ec1b389f41e0fa4149d6e`) |
| **Scope** | Read-only independent final review of PR15 stacked on PR14, PR16 ThemeToggle fix, combined integration candidate, OpenSpec tasks 4.1/4.2/5.7/5.10/5.12/5.14, evidence claims in `recovery-20261024/final-current/` and `deferred-ordinary-acceptance.md` |
| **Limitations** | • No builds, tests, application launches, or Git mutations performed<br>• No `verify/runs/`, `verify/baselines/`, `verify/.signing/` inspected (execution evidence, not source)<br>• Combined runtime Gallery/UIA NOT_EXECUTED — source equality only<br>• Allocator-free 5M ingestion NOT_EXECUTED — preflight binding only<br>• Final independent review BLOCKED_EXTERNAL — no verdict on `4c1c450`<br>• Hot/cold 5M equivalence contract ambiguity requires owner clarification (cannot be resolved by review) |
| **Non-self-referential** | All SHAs derived from WORKSTATE, evidence manifests, and git history; no self-referential commit containing this review |

---

**End of Review**