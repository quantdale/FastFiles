Now I have a thorough understanding of all the files in scope. Let me compile the complete review.

## Review

### Correct (what is already good with evidence)

- **Allocator-free wrapper is correctly isolated**: `bench_ingestion_uninstrumented.cpp` defines `FFBENCH_NO_ALLOCATOR_PROBE=1` before including `bench_large_index_scalability.cpp`, undefines `wmain`, and provides its own entry point without allocator probe or stage timers (lines 1-6, 13-79). The CMake target `ffengine_bench_ingestion_uninstrumented` links the same production sources without the probe define (tests/engine/CMakeLists.txt:298-307). The output JSON explicitly records `"allocator_probe_enabled":false` and `"stage_timers_enabled":false` (bench_ingestion_uninstrumented.cpp:28-30).

- **Identity-ordering oracle has deterministic fixture handling**: `bench_identity_ordering_oracle.cpp` creates its own SQLite backup copy via `sqlite3_backup` (lines 45-77) or opens the fixture read-only via enforced `mode=ro` URI with a per-connection read-only extension guard (lines 79-122). The source fixture is never mutated. The comparator `SequenceEqual` checks all candidate fields including `allocatedSizeBytes` and `allocatedSizeKnown` (lines 127-148). Self-test validates ordering sensitivity (lines 150-169).

- **Oracle correctly separates candidate and canonical routes**: `forceCanonicalColdScan` hook bypasses ALL name prefilters (bench_identity_ordering_oracle.cpp:177-180). The `candidatePlannerProbe` hook records route admissions (lines 181-184). Premises require canonical scan examines all rows (`canonical.coldRows == rows`), zero hot rows, zero candidate routes, and indexed route admits candidates only when `requireIndex` is set (lines 218-225). Nonvacuous premise asserts canonical results nonempty except for `no_match` (line 226).

- **Candidate resource harness measures production schema with maintenance A/B**: `bench_candidate_index_resources.cpp` uses `MaintenanceScope` RAII to toggle `SetTestingCandidateMaintenanceDisabled` (lines 61-64, 142-143). Arms measure ingestion with/without candidate maintenance, WAL peak via 100ms polling `WalWatcher` (lines 66-83), private bytes via `GetProcessMemoryInfo` (lines 85-93). Migration and rebuild-on-open timings are measured on the same database after controlled schema tampering (lines 277-318). Lifecycle arms (rename/mass-remove/reinsert/ForgetVolume) run A/B on the same scale (lines 95-274).

- **Projection memory decomposition has complete methodology**: `bench_large_index_scalability.cpp` memory mode (lines 1150+) captures `GetProcessMemoryInfo` working set/private bytes, `QueryWorkingSet`/`QueryWorkingSetEx` page classification (shareable vs private), allocator probe live/cumulative requested/usable bytes and counts (bench_allocator_probe.h), and `Projection::GetMemoryBreakdown` live capacity measurements. Rebuild cycles and close/reopen/rebuild plateau evidence are included. Export weighing uses counterbalanced pooled/owning arms with payload hash verification (lines 1420-1520).

- **Store open phase profiling uses fresh processes with executable identity**: `bench_store_open.cpp` spawns child processes via `CreateProcess` with stdout pipe capture (lines 415-485). Each child runs `--measure-child` mode, applies case pre-state before every open (lines 215-260), and emits per-open JSON with phase timings from `Store::OpenPhaseTimings`. Parent aggregates p50/p90/max across processes. Runtime executable SHA-256 is computed via BCrypt and recorded alongside caller-asserted source identity (lines 380-410, 490-570).

- **Rebuild isolation matrix attributes cost to constituent operations**: `bench_rebuild_isolation.cpp` defines arms A (fresh build), B1/B2 (remove+rebuild), C (clear+build), D (double-buffer), E1/E2 (skip filename maintenance), F1 (skip child unlink), G0/G1/G2 (no-trigram ceiling) with `FF_INDEXSTORE_TESTING` seam compiled only into this target (tests/indexstore/CMakeLists.txt:38-42). Each arm captures projection state (filename index valid, estimated bytes, evicted volumes) and memory samples (lines 160-195).

- **SQLite write fault VFS injects real SQLITE_FULL from xWrite**: `SqliteWriteFaultVfs.h` wraps the default VFS, intercepts `xWrite`, and returns `SQLITE_FULL` on the armed nth write matching file kind (wal/database) and optional SQL filter (lines 140-165). Statement tracing captures current SQL and commit state (lines 105-130). This is used by `ffengine_storage_pressure_tests --ordinary-only` for simulated error returns without physical exhaustion (WORKSTATE.md line 127-128).

- **Deferred acceptance document honestly discloses unexecuted cells**: `deferred-ordinary-acceptance.md` explicitly lists NOT_EXECUTED items (hot5M, allocator-free5M, multi-volume/cap performance, large-WAL, deliberate termination) with reasons (disk capacity, preflight rejection) and merge impact (tasks 4.1, 4.2, 5.7, 5.10, 5.12, 5.14 open). No requirement is silently relaxed (deferred-ordinary-acceptance.md:1-4, table).

---

### Finding: P0 — Allocator-free 5M ingestion NOT EXECUTED; preflight rejects at ~966MB free

**Location**: `tests/engine/bench_ingestion_uninstrumented.cpp:52-55` (preflight check), `evidence/ordinary-recovery-owner-report.md:152`, `deferred-ordinary-acceptance.md:11`

**Evidence**: 
- The uninstrumented target has an operational safety floor: `minimum = scale >= 3'000'000 ? 4 GiB : 2 GiB` available space (bench_ingestion_uninstrumented.cpp:52-54). At 966,193,152 bytes free, the 5M run exits with code 3 before inserting any row (ordinary-recovery-owner-report.md:152).
- WORKSTATE.md line 19: "Current5M allocator-free dispatch was refused by preflight at 966,193,152B free, exit 3 **before any ingestion row**. Full5M ingestion and current3.1M-cliff runtime are NOT_EXECUTED; no extrapolation."
- The allocator-free 200k/1M stages at dab2128 are historical (3.15s / 30.7s) and explicitly NOT final 4c1c450 timings (WORKSTATE.md:19).

**Impact**: The primary production-path ingestion measurement at 5M rows is missing. The 3.1M cliff runtime (where projection enforcement dominates) is unmeasured on final source. Merge verdict cannot assume large-scale ingestion performance.

**Smallest fix**: Provision ≥4 GiB free on temp volume and run `ffengine_bench_ingestion_uninstrumented --scales 5000000 --output ... --source-sha <sha> --source-state clean --preset release-test`. Do not weaken the preflight or substitute structural eviction guards for runtime evidence.

---

### Finding: P0 — Hot/cold identity at 5M NOT EXECUTED; only cold-vs-canonical oracle at 5M

**Location**: `deferred-ordinary-acceptance.md:6-7`, `evidence/ordinary-recovery-owner-report.md:58-60`

**Evidence**:
- "Fully-hot versus cold identity/order at all mandated scales, including 5M: UNPROVEN; hot5M not executed" (deferred-ordinary-acceptance.md:6).
- Oracle executable SHA256 `0b9ec97ec7b0e1cdc2af67641f265aa0161a136759155286eca96a7d84ed5ca3` (ordinary-recovery-owner-report.md:17).
- Current oracle passes 13/13 cells at 5M but this is **capped cold equivalence** (read-only fixture, projection unloaded, selective/exact/no-match: 12.86/7.78/1.84ms vs 5M canonical rows), not fully-hot/uncapped/targeted 5M acceptance (ordinary-recovery-owner-report.md:58-60).
- The fixture/timing boundary differs from the historical pipeline ingestion fixture (628de6d/5d7e98a); do not pool (ordinary-recovery-owner-report.md:60).

**Impact**: Task 4.1 (hot/cold identity at all scales) remains merge-blocking. The oracle proves the candidate route matches the canonical stream under forced-cold conditions, but does not exercise the hot projection path at 5M rows.

**Smallest fix**: Run the oracle against a 5M fixture with projection resident (remove `UnloadVolumeFromProjection` calls) for hot path, or accept task 4.1 as explicitly open with documented scope limitation.

---

### Finding: P1 — Multi-volume selective and candidate-cap performance cells NOT EXECUTED

**Location**: `deferred-ordinary-acceptance.md:8-9`, `evidence/ordinary-recovery-owner-report.md:62`

**Evidence**:
- "Same pipeline-fixture 2M repeat matrix, multi-volume selective and candidate-cap performance boundaries: NOT_EXECUTED / disk capacity" (deferred-ordinary-acceptance.md:8).
- "Multi-volume/candidate-cap 2M performance cells and the same pipeline-fixture repeat matrix remain open under 5.7" (ordinary-recovery-owner-report.md:62).
- Automatic mixed-volume eviction/concurrency/export test passes in latest 3-test run (WORKSTATE.md:31) but this is a correctness test, not the performance boundary measurement.

**Impact**: Task 5.7 (multi-volume/cap performance) remains open. The cost-based cap (16,384) behavior under multi-volume cold fallback and candidate admission pressure is unmeasured at scale.

**Smallest fix**: Provision scratch capacity for multi-volume fixture generation and run the scalability benchmark with `--scales` including multi-volume configurations, or explicitly scope task 5.7 as deferred with owner acceptance.

---

### Finding: P1 — Large-scale pinned-reader WAL/resource growth only at bounded fixture scale

**Location**: `deferred-ordinary-acceptance.md:10-11`, `bench_candidate_index_resources.cpp:66-83`

**Evidence**:
- "Large-scale pinned-reader WAL/resource growth: PASS_WITH_LIMITATION only at bounded fixture scale" (deferred-ordinary-acceptance.md:10).
- `WalWatcher` polls at 100ms intervals (bench_candidate_index_resources.cpp:77); peak WAL observed at 1,668,632 bytes in small test (WORKSTATE.md:131).
- "No finite universal WAL cap claimed" (deferred-ordinary-acceptance.md:11). Prior 648MB migration sample and 960MB lifecycle sample are explicitly not universal bounds (deferred-ordinary-acceptance.md:18-19).

**Impact**: Task 4.2 resource acceptance is qualified only at small scale. The 15.6 MiB production checkpoint threshold (IndexPipeline.cpp:334, reflected in bench_candidate_index_resources.cpp:89 as `4000ull * 4096ull`) is exercised per-batch in lifecycle arms, but WAL growth under sustained pinned readers at 5M+ scale is uncharacterized.

**Smallest fix**: Run lifecycle arms at larger scales with extended pinned-reader duration, or document the operational assumption that capacity must cover largest atomic operation + retained reader history without a universal cap guarantee.

---

### Finding: P1 — Deliberate process termination / restart interruption cells NOT EXECUTED

**Location**: `deferred-ordinary-acceptance.md:12-13`, `WORKSTATE.md:24-25`

**Evidence**:
- "Deliberate large-removal process termination / restart interruption: NOT_EXECUTED in this continuation; outside owner scope" (deferred-ordinary-acceptance.md:12).
- "Deliberate termination/restart interruption cells were NOT_EXECUTED under the continuation scope; earlier results stay historical" (ordinary-recovery-owner-report.md:142).
- "No live user application was manually terminated, privileged storage operation performed, actual user database modified" (ordinary-recovery-owner-report.md:143).

**Impact**: Transaction/checkpoint/bookkeeping boundaries and rescan reconstruction after hard kill are not validated on current source. The `bench_store_open.cpp` migration-v2-interrupted case (lines 330-340) uses a deterministic hard-exit fault seam but this is a controlled single-crash child, not the full deliberate-termination matrix.

**Smallest fix**: Either execute a separate permitted validation plan for crash/recovery boundaries, or keep these cells explicitly deferred with no silent relaxation (current state is correct).

---

### Finding: P1 — Final independent Store/manager/performance review BLOCKED_EXTERNAL

**Location**: `deferred-ordinary-acceptance.md:14-15`, `evidence/ordinary-recovery-owner-report.md:27-31`

**Evidence**:
- "Final independent Store/manager/performance review: BLOCKED_EXTERNAL: provider usage limit" (deferred-ordinary-acceptance.md:14).
- Five initial source reviews and projection follow-up completed at 8c4c848; two later data/performance follow-ups at dab2128 failed with `Codex error: The usage limit has been reached` before verdicts (ordinary-recovery-owner-report.md:27-30).
- Disclosed fixed-route opencode/hy3-free doctor also failed static preflight; no fallback around it (ordinary-recovery-owner-report.md:30-31).
- Tasks 5.10/5.14 remain open; no final 4c1c450 approval claimed (ordinary-recovery-owner-report.md:31).

**Impact**: No independent review verdict on the final implementation (4c1c450). The owner report explicitly states "No final 4c1c450 approval is claimed" and "PRODUCT_CORRECTNESS: PASS_WITH_LIMITATION: tested repairs; final independent review unavailable" (ordinary-recovery-owner-report.md:225).

**Smallest fix**: Restore independent reviewer availability; inspect final 4c1c450 source and latest harness. No billing/provider-policy changes by agent (ordinary-recovery-owner-report.md:238).

---

### Finding: P1 — Combined PR15+PR16 full application Debug/release builds and runtime Gallery/UIA NOT EXECUTED

**Location**: `deferred-ordinary-acceptance.md:16-17`, `evidence/ordinary-recovery-owner-report.md:166-170`

**Evidence**:
- "Combined PR15+PR16 full application Debug/release builds and runtime Gallery/UIA: NOT_EXECUTED / disk capacity" (deferred-ordinary-acceptance.md:16).
- Isolated combined source `6d3de0e8c9242315bad004cefc685f8f2f75b2b9` has focused Debug/release 3/3 pass but "Full combined application builds, Gallery and UIA are NOT_EXECUTED with roughly 1GiB free" (ordinary-recovery-owner-report.md:168).
- "Therefore full PR16_COMPATIBLE_WITH_PR15 remains UNPROVEN; source/focused compatibility alone does not close 5.12" (ordinary-recovery-owner-report.md:169).

**Impact**: Task 5.12 (Gallery integration/compatibility) cannot be closed by source compatibility alone. PR15 catalog 17/20 fails gallery-dark/narrow/wide; PR16 passes 20/20 standalone but combined runtime is untested.

**Smallest fix**: Complete combined runtime qualification with adequate disk headroom, or obtain explicit owner governance decision on Gallery exclusion/dependency.

---

### Finding: P1 — Hosted certification NOT_OBTAINED; local parity ≠ hosted execution

**Location**: `deferred-ordinary-acceptance.md:19-20`, `evidence/ordinary-recovery-owner-report.md:228, 238`

**Evidence**:
- "Hosted certification: NOT_OBTAINED at previous run; inspect final push once" (deferred-ordinary-acceptance.md:19).
- "Local canonical parity 11/11, not hosted execution" (deferred-ordinary-acceptance.md:20).
- "If hosted execution still fails before steps, restore external infrastructure; local parity is not hosted certification" (ordinary-recovery-owner-report.md:238).
- Prior hosted runs (e.g., 39972399750) had six failed jobs, zero steps (WORKSTATE.md:87).

**Impact**: The full certification ladder requires a hosted CI inspection. Local gates passing does not substitute for hosted execution.

**Smallest fix**: Restore hosted infrastructure if final push again has zero steps; inspect final pushed SHA once. No billing/policy changes by agent.

---

### Finding: P2 — Oracle executable records only build identity, not runtime executable hash

**Location**: `bench_identity_ordering_oracle.cpp:229-231`, `evidence/recovery-20261024/provenance-review.md:91`

**Evidence**:
- Oracle records only `kBuildIdentityAscii` (bench_identity_ordering_oracle.cpp:229-231: `out << "\"build_identity\":" << Json(ffsetup::kBuildIdentityAscii)`).
- Store-open artifacts additionally record a runtime executable hash (provenance-review.md:91: "the oracle records only `kBuildIdentityAscii` ... whereas store-open artifacts additionally record a runtime executable hash").
- "Caller-supplied clean/source labels remain assertions. No evidence of an actual mismatched executable was established." (provenance-review.md:91-92).

**Impact**: The oracle artifact's executable identity is weaker than the store-open harness. A mismatched executable (rebuilt from different source) would not be detected by the oracle's own artifact.

**Smallest fix**: Add runtime executable SHA-256 computation (via BCrypt as in bench_store_open.cpp:120-155) to the oracle output JSON.

---

### Finding: P2 — Benchmark watcher data race and false success fixed but historical context incomplete

**Location**: `WORKSTATE.md:31, 34`, `bench_large_index_scalability.cpp:1680-1800` (ContentionBarrier usage)

**Evidence**:
- "Benchmark watcher data race and false success for incomplete/output-failed measurements. The allocator-free target is separate from historical probes." (WORKSTATE.md:31).
- "Benchmark C findings fixed: atomic watcher stop, incomplete-arm/preparation/output failures return nonzero, maintenance seam resets by RAII. Historical prebuilt missing-output-parent repro exits 0; repaired binary exits 1" (WORKSTATE.md:34).
- The `ContentionBarrier` in bench_large_index_scalability.cpp uses condition variables for thread synchronization (lines 265-290), but the historical false-success issue suggests the harness previously allowed incomplete runs to report success.

**Impact**: The current harness correctly returns nonzero on incomplete/output failures, but the fix is recent and the historical false-success baseline means prior benchmark artifacts from the same harness may be unreliable.

**Smallest fix**: Ensure all benchmark artifacts in evidence are from the repaired harness (post atomic watcher stop fix). Regenerate any retained historical benchmark JSON with the current binary.

---

### Finding: P2 — Working-set split (QueryWorkingSetEx) availability not guaranteed; limitation documented but not enforced

**Location**: `bench_large_index_scalability.cpp:1260-1310`, `bench_large_index_scalability.cpp:2080-2090` (limitations array)

**Evidence**:
- `ReadWorkingSetSplit()` attempts up to 6 capacity doublings but returns `available=false` if `QueryWorkingSetEx` fails (lines 1280-1295).
- Limitations array documents: "working-set shareable pages identify shareable/pagefile-backed pages; they are not proof that another process maps the same section" (line 2085).
- The memory decomposition report includes `working_set_split.available` field but downstream analysis must handle `false`.

**Impact**: On some Windows configurations (e.g., missing PSAPI privileges, version differences), the shareable/private page classification may be unavailable, reducing the decomposition's diagnostic value without failing the run.

**Smallest fix**: Documented limitation is acceptable for an informational benchmark. Consider adding a diagnostic warning when `available=false` to alert operators.

---

### Finding: P2 — SQLite C allocations excluded from allocator probe; residual appears in private bytes

**Location**: `bench_allocator_probe.h:10-15`, `bench_large_index_scalability.cpp:2080-2085`

**Evidence**:
- "SQLite is compiled as C and allocates through malloc/free directly, so the durable store's pages and per-connection bookkeeping are deliberately outside this counter; they show up in the process-private reconciliation instead of being invented here" (bench_allocator_probe.h:12-15).
- Limitations: "allocator counts cover C++ operator new/delete only; SQLite (compiled as C) allocates through malloc/free and appears in the private-bytes residual instead" (bench_large_index_scalability.cpp:2082-2084).

**Impact**: The allocator probe does not account for SQLite's internal allocations (page cache, WAL buffers, statement heaps). The "private-bytes residual" conflates allocator overhead, SQLite allocations, and other CRT allocations.

**Smallest fix**: This is a stated measurement boundary, not a defect. The decomposition explicitly reconciles allocator deltas against projection category sums and treats the residual as unexplained overhead (bench_large_index_scalability.cpp:2090-2092). No code change needed; ensure consumers understand the boundary.

---

### Finding: P2 — Projection memory budget (500 MiB) is estimator policy, not RSS cap; correctly disclosed

**Location**: `deferred-ordinary-acceptance.md:17`, `bench_large_index_scalability.cpp:1470` (identity block), `ordinary-recovery-owner-report.md:141`

**Evidence**:
- "The 500MiB projection budget and 400MiB watermark govern an estimator/residency policy, not process RSS/private bytes. SQLite caches, temporary compaction, allocator overhead and other components require separate capacity." (deferred-ordinary-acceptance.md:17).
- Benchmark identity block records `"projection_memory_budget_bytes":524288000` and `"projection_memory_budget_note":"default 500 MiB unchanged"` (bench_large_index_scalability.cpp:1470-1471, bench_store_open.cpp:550).
- "Default projection budget 500MiB / watermark 400MiB is unchanged, **not an RSS ceiling**" (ordinary-recovery-owner-report.md:141).

**Impact**: Correctly disclosed. The budget is a projection-internal estimator threshold driving eviction, not a process memory limit. Consumers must not interpret it as an RSS guarantee.

**Smallest fix**: None needed; disclosure is accurate and consistent across artifacts.

---

### Finding: P2 — Source/exe binding: oracle and benchmarks use caller-asserted source SHA/state; only store-open computes runtime exe hash

**Location**: `bench_identity_ordering_oracle.cpp:229-231`, `bench_large_index_scalability.cpp:1460-1470`, `bench_store_open.cpp:380-410, 490-570`

**Evidence**:
- Oracle: records `build_identity` only (bench_identity_ordering_oracle.cpp:229-231).
- Large index scalability: records `source_sha`, `source_state`, `preset`, `build_identity`, `command_line` as caller-asserted (bench_large_index_scalability.cpp:1460-1470).
- Store-open: computes runtime executable SHA-256 via BCrypt, records `executable_sha256_computed: "runtime"`, and optionally compares against `executable_sha256_expected` (bench_store_open.cpp:380-410, 500-510).

**Impact**: The oracle and scalability benchmark rely on caller-supplied source identity assertions. Only store-open has self-computed executable identity verification. A mismatched executable (e.g., rebuilt from dirty tree without --source-state update) would not be caught by oracle/scalability artifacts.

**Smallest fix**: Add runtime executable hash to oracle and scalability benchmark outputs for consistent provenance. The infrastructure exists in bench_store_open.cpp.

---

### Finding: P2 — Deterministic fixture equivalence: oracle uses read-only fixture; scalability benchmark generates fresh fixture each run

**Location**: `bench_identity_ordering_oracle.cpp:45-122`, `bench_large_index_scalability.cpp:300-370` (BuildSyntheticDatabase)

**Evidence**:
- Oracle: copies source fixture to scratch via SQLite backup (read-only source) or opens source read-only via `mode=ro` URI. Source fixture hash unchanged (ordinary-recovery-owner-report.md:57: "Source SHA256 is unchanged before/after every run").
- Scalability benchmark: `BuildSyntheticDatabase` generates deterministic synthetic data from scratch each run (bench_large_index_scalability.cpp:300-370). No fixture reuse across runs.
- "This Store fixture/timing boundary differs from the older pipeline fixture and its warmup protocol; do not infer a regression/speedup by pooling it with 628de6d timings" (ordinary-recovery-owner-report.md:60).

**Impact**: The oracle and scalability benchmark operate on different fixture boundaries (oracle = read-only copy of existing 5M v3 fixture; scalability = freshly generated synthetic data). Timing comparisons across these harnesses are not valid.

**Smallest fix**: Clearly label each artifact's fixture provenance (already done in JSON schemas: `fixture_access`, `fixture_generation`). Do not cross-compare timings across different fixture generation methods.

---

### Finding: P2 — Cache/sample/CPU/memory/WAL methodology: single-run wall-clock, no OS cache flush, no p95 from n=3

**Location**: `ordinary-recovery-owner-report.md:55-56`, `bench_large_index_scalability.cpp:430-440` (warm runs), `bench_store_open.cpp:520-530` (processCount=5 default)

**Evidence**:
- "These are first iterations within an ordered matrix, **not OS-cache-flushed cold**, and no p95 is inferred from three samples" (ordinary-recovery-owner-report.md:56).
- Scalability benchmark: 1 cold-ish run + 2 warmup + 10 warm runs (5 for large scales) per query class (bench_large_index_scalability.cpp:430-440). Median reported from warm runs only.
- Store-open: default 5 fresh processes, 0 warm opens per process (bench_store_open.cpp:520-530). Aggregate p50/p90/max across processes.
- CPU: `GetProcessTimes` kernel+user time (bench_ingestion_uninstrumented.cpp:13-20, bench_store_open.cpp:280-295).
- WAL: 100ms polling file size (bench_candidate_index_resources.cpp:77), not continuous.

**Impact**: Measurements are single-run, cache-warm (after first iteration), and statistically thin (n=3 to n=10). No cold-cache flush, no confidence intervals, no multi-run aggregation beyond the single benchmark execution.

**Smallest fix**: Methodology is appropriate for informational benchmarks. If stronger claims are needed, add OS cache flush (e.g., `FlushFileBuffers` + memory pressure), increase process count, and compute confidence intervals. Current disclosure is honest.

---

### Finding: P2 — Historical pipeline fixture vs current Store oracle: different fixtures, different timing boundaries

**Location**: `ordinary-recovery-owner-report.md:57-60`, `deferred-ordinary-acceptance.md:6-7`

**Evidence**:
- Oracle uses "verified 2M synthetic Store fixture" (read-only, v3 schema) and "current 5M read-only oracle" (ordinary-recovery-owner-report.md:57, 59).
- "This Store fixture/timing boundary differs from the older pipeline fixture and its warmup protocol; do not infer a regression/speedup by pooling it with 628de6d timings" (ordinary-recovery-owner-report.md:60).
- Historical 5M ingestion at 5d7e98a: 132.368s (allocator-instrumented). Historical 5M oracle at 628de6d: different fixture (pipeline ingestion output) (WORKSTATE.md:93-94).

**Impact**: The current Store oracle is a distinct measurement from the historical pipeline scalability harness. They use different fixtures (Store synthetic vs pipeline ingestion output), different harnesses, and different timing boundaries. Pooling them would be invalid.

**Smallest fix**: Already correctly disclosed. Maintain separate evidence tracks; do not cross-reference timings without explicit qualification.

---

### Finding: P3 — Ordinary browsing/multi-volume regressions: source-grounded assessment

**Location**: `WORKSTATE.md:135-138`, `ordinary-recovery-owner-report.md:135-143`, `deferred-ordinary-acceptance.md:8-9`

**Evidence**:
- Degraded mode is the active path: `DegradedModeEnumerator` (FindFirstFileEx tree walks) + `DirectoryWatcher` (ReadDirectoryChangesW per browsed/pinned root) (AGENTS.md:58-60).
- "Column View browses through the degraded path... shown as a small non-modal status badge. Degraded mode is a first-class, permanent state — not an error path" (AGENTS.md:59-60).
- Ordinary recovery composition tests pass: automatic ingestion-driven cold fallback during parked search invalidates cursor, returns exact mixed-volume identities, small hot volume and snapshot survive, alternating ingestion/search/export consistent (ordinary-recovery-owner-report.md:138-140).
- Multi-volume/cap performance cells NOT_EXECUTED (deferred-ordinary-acceptance.md:8).
- PR16 separate fix passes catalog 20/20; combined runtime NOT_EXECUTED (ordinary-recovery-owner-report.md:166-170).

**Impact**: 
- Correctness: Ordinary browsing path (degraded mode) is tested and passing via `ffengine_storage_pressure_tests --ordinary-only`, `ffengine_degraded_special_files_tests`, `ffengine_directory_watcher_tests`, `ffengine_active_path_resilience_tests`.
- Multi-volume correctness: Automatic mixed-volume eviction/concurrency/export test passes (WORKSTATE.md:31).
- Performance: Multi-volume selective/cap boundaries at scale are unmeasured (task 5.7).
- Combined PR15+PR16 Gallery/UIA runtime untested (task 5.12).

**Assessment**: No source-grounded regression in ordinary browsing correctness. The degraded mode path is fully exercised by the test suite. Performance boundaries at multi-volume scale remain open (task 5.7). Combined UI compatibility with PR16 fix is unproven at runtime (task 5.12).

---

### Merge verdict: BLOCK

**Rationale**: Multiple P0/P1 findings block merge readiness:
1. **P0**: Allocator-free 5M ingestion NOT EXECUTED (preflight rejection at ~966MB free)
2. **P0**: Hot/cold identity at 5M NOT EXECUTED (only cold-vs-canonical oracle)
3. **P1**: Multi-volume/cap performance cells NOT EXECUTED
4. **P1**: Large-scale pinned-reader WAL/resource growth only at bounded scale
5. **P1**: Deliberate crash/restart interruption cells NOT EXECUTED
6. **P1**: Final independent review BLOCKED_EXTERNAL (provider quota)
7. **P1**: Combined PR15+PR16 full runtime Gallery/UIA NOT EXECUTED
8. **P1**: Hosted certification NOT_OBTAINED

The `deferred-ordinary-acceptance.md` and `ordinary-recovery-owner-report.md` honestly disclose all limitations. No requirement is silently relaxed. The implementation (4c1c450) passes all executed local gates (Debug 130/130, release-test 130/130, Analyze clean, ASan 4/4, parity 11/11, E2E 8/8, UIA core/visual 25/25, full UIA 23/5/0). However, the acceptance criteria defined in the OpenSpec change (tasks 4.1, 4.2, 5.7, 5.10, 5.12, 5.14) remain open with concrete evidence gaps.

**Reviewed SHA**: 4c1c4501e5b1f0579a2d34f4f7afea5f83708979 (implementation), 269d1c36036cb84b40c3ef01baee3c2b6c990579 (clean executed validation source)

**Scope**: Read-only independent final review of PR15 at HEAD 2ff3b595940d95c706fa815b72ffee1c8d53fb44. Scope C: tests/engine/bench_large_index_scalability.cpp and allocator-free wrapper/profile targets; tests/indexstore identity-order oracle and resource benchmarks; evidence/ordinary-recovery-owner-report.md and deferred-ordinary-acceptance.md under durable-cold-search change.

**Limitations**: 
- No builds, test execution, or database mutations performed (read-only review).
- Did not read/glob `verify/runs/`, `verify/baselines/`, `verify/.signing/` per instructions.
- Historical review reports (8c4c848, 5d7e98a, etc.) referenced but not treated as current approval.
- Disk capacity constraints (~1 GiB free) acknowledged as cause for NOT_EXECUTED cells.
- Ordinary development scope only; no privileged/trust-store/production signing validation.
- Source/executable binding verified from source code; runtime verification of artifact generation not performed.