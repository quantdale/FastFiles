---

## Review: FastFiles PR15 at HEAD 2ff3b595940d95c706fa815b72ffee1c8d53fb44 (executable 4c1c4501e5b1f0579a2d34f4f7afea5f83708979)

**Scope B:** `Projection.cpp/.h`, `IndexPipeline` memory/residency/search epochs and snapshots. Bulk volume eviction, sibling unlink, free-list release, LRU, memory accounting, 500MiB/400MiB convergence, cold fallback after eight unsuccessful passes, mixed volumes, cursors, reload fail-fast, snapshot publication. Regression tests beyond prior 3.1M benchmark improvement.

---

### Correct (with evidence)

| Area | Evidence |
|------|----------|
| **Projection memory breakdown accuracy** | `Projection::GetMemoryBreakdown()` (Projection.cpp:765–920) sums `modeledCategoryBytes` exactly matching `EstimatedMemoryBytes()`; unit test `TestProjectionMemoryBreakdownMatchesEstimatorAndCategories` (test_projection.cpp:1103–1223) asserts equality. Every category uses live `capacity()`/`size()`/`bucket_count()` measurements. |
| **Dense LRU timestamps survive compaction/eviction** | `lastAccessTimes_` vector permuted in `CompactEntriesForIterationOrder()` (Projection.cpp:1208–1245) with `remap`; test `TestLruTimestampsSurviveIterationOrderCompaction` (test_projection.cpp:1353–1420) uses discriminator precondition (probe order ≠ stream order) to prove timestamps track logical rows, not slots. |
| **Bulk removal O(N) vs per-entry O(N²) posting erases** | `RemoveBatch` (Projection.cpp:1267–1305) switches to `InvalidateFilenameIndex()` + single `RebuildFilenameIndex()` when `frns.size() > 256`; `TestRemoveBatchMatchesPerEntryRemoval` (test_projection.cpp:1422–1476) validates observable equivalence. |
| **Eviction marks volumes cold; reload is fail-fast** | `EvictVolume` (Projection.cpp:626–647) collects keys then erases from `idToIndex_` in O(N) without sibling search; `ReloadEvictedVolume` (Projection.cpp:732–752) returns `false` on store failure, leaves `evictedVolumes_` marker, increments `coldReloadFailedCount_`; test `TestProjectionRebuildFailureIsColdAndRetryable` (test_projection.cpp:773–824) proves failed rebuild retains cold marker and removes partial rows. |
| **Projection residency epochs advance on structural change** | `AdvanceResidencyEpochsForStructuralChangeLocked()` (IndexPipeline.cpp:371–385) bumps `ProjectionResidency` epoch for all volumes after `EnforceMemoryLimitNow()` (IndexPipeline.cpp:864, 969) and cold reload (IndexPipeline.cpp:1114); in-flight searches restart via generation restart logic (IndexPipeline.cpp:1430–1440). |
| **Eight-pass fine-grained enforcement then whole-volume cold fallback** | `EnforceMemoryLimit()` (Projection.cpp:677–713): `kMaxEnforcementPasses = 8` loop with progress guard; then `while (EstimatedMemoryBytes() > lowWatermark) { EvictVolume(victim->volumeRowId); }`. Comment documents measured 3.1M cliff (12–13s enforcement vs 0.17s store write). |
| **Cursor `Stale()` detects layout disturbance** | `ProjectionEntryCursor::Stale()` (Projection.cpp:1044–1056) compares `entries_.data()` and `idToIndex_.bucket_count()`; `Next()` returns `false` on stale (IndexPipeline.cpp:1538, 1568) → search restarts. Test `TestManyDistinctParentsDoNotStallGrowth` (test_projection.cpp:595–612) exercises growth past initial buckets. |
| **Snapshot publisher uses immutable generations** | `SnapshotPublisher` (test_snapshot_publisher.cpp) commits generation 0 at `Start()`, each `Publish()` writes new section, advances generation; stale readers hold old mapping (verified by mapping `firstHeader->generation` after second publish). |
| **Bulk scan defers eviction/compaction, revives accelerator on end** | `SetBulkScanActive(true)` (Projection.cpp:602–618) disables enforcement, invalidates filename index; `SetBulkScanActive(false)` re-enables enforcement AND calls `RebuildFilenameIndex()` (review-lane C Finding 3 fix). |
| **500MiB default, 400MiB low watermark (80%)** | `kDefaultMaximumMemoryBytes = 500MiB` (Projection.h:54); `lowWatermark = maximumMemoryBytes_ - maximumMemoryBytes_/5` (Projection.cpp:657, 678); `IsMemoryPressureHigh()` uses same 80% threshold. |
| **Free-list released on full compaction** | `CompactStorage()` (Projection.cpp:649–688) does `std::vector<uint32_t>().swap(freeList_)` — releases capacity after full-volume eviction/rebuild. |
| **Cold fallback path uses independent WAL snapshot** | `SearchIndexedReadPlane` (IndexPipeline.cpp:1110) opens `StoreReadSession` outside pipeline mutex for cold volumes; `MaterializeCandidateFolderDurable` walks parent chain via read session, never blocking writer. |

---

### Finding: P0 — Cold fallback after eight passes evicts **LRU victim's entire volume**, not just the subtree

**Location:** `Projection.cpp:702–711` (`EnforceMemoryLimit` while loop)

```cpp
while (EstimatedMemoryBytes() > lowWatermark) {
    const auto victim = LeastRecentlyUsedEntry();
    if (!victim.has_value()) break;
    const size_t before = EstimatedMemoryBytes();
    EvictVolume(victim->volumeRowId);  // <-- WHOLE VOLUME, not subtree
    evictedAny = true;
    ...
}
```

**Issue:** The comment says "Every iteration removes a whole volume, rather than one small subtree" — but `LeastRecentlyUsedEntry()` returns a single entry key (file or directory). `EvictVolume(volumeRowId)` then evicts **all entries of that volume** (Projection.cpp:626–647), not the victim's subtree.

**Reachable failure:** Under memory pressure with multiple volumes, a single LRU file in Volume B causes **entire Volume B** to go cold. This is a massive over-eviction (could be millions of rows) when the policy intent was fine-grained subtree eviction. The eight fine-grained passes already failed to converge; falling back to whole-volume eviction per LRU entry is a cliff, not a gradient.

**Regression adequacy:** No test exercises multi-volume memory pressure with LRU selection crossing volume boundaries. `TestProjectionEvictsLruAndReloadsFromStore` (test_projection.cpp:675–771) uses single volume. `TestProjectionMemoryDiagnostics` (test_projection.cpp:826–930) single volume. The 3.1M benchmark was single-volume.

**Smallest fix:** Change fallback to `EvictSubtree(*victim)` (single subtree) with a volume-level cap, OR document/rename the fallback as "whole-volume cold residency" and add a test proving the over-eviction is bounded (e.g., max one volume per enforcement cycle).

---

### Finding: P1 — `EvictSubtree` does per-entry `Remove()` in a loop; quadratic sibling unlink persists for large directories

**Location:** `Projection.cpp:589–623` (`EvictSubtree`)

```cpp
for (auto it = removalOrder.rbegin(); it != removalOrder.rend(); ++it) {
    Remove(it->volumeRowId, it->frn);  // calls RemoveFromChildrenList per entry
}
```

`RemoveFromChildrenList` → `parentToChildren_.remove(parentKey, index)` (FlatHashMap.h). For a directory with *k* children, each `remove` does a linear scan of that parent's child slice (O(k) per child = O(k²) total). This is the same quadratic sibling unlink identified in `large-index-lifecycle-and-search-scalability` review-lane D (B1: 12,983 ms vs E1: 44.8 ms at 200k).

**Reachable failure:** `EvictSubtree` on a large flat directory (e.g., 100k files in one folder) during memory enforcement will stall the ingestion pipeline mutex for seconds. The fix in `RemoveBatch` (bulk removal with `InvalidateFilenameIndex()` + single `CompactStorage()`) is not used here.

**Evidence:** `EvictVolume` (Projection.cpp:626–647) correctly uses bulk key collection + single `CompactStorage()` — but `EvictSubtree` does not.

**Smallest fix:** In `EvictSubtree`, collect all descendant keys, then `idToIndex_.erase(key)` in a loop (like `EvictVolume`), then single `CompactStorage()`. Skip per-entry `RemoveFromChildrenList` and filename index maintenance (accelerator invalidated anyway by `CompactStorage`).

---

### Finding: P1 — `EnforceMemoryLimitOnceTo` calls `EvictSubtree` + `CompactStorage` per pass; eight passes = eight full compactions

**Location:** `Projection.cpp:715–730` (`EnforceMemoryLimitOnceTo`)

```cpp
bool Projection::EnforceMemoryLimitOnceTo(const size_t targetBytes) {
    ...
    const auto victim = LeastRecentlyUsedEntry();
    if (!victim.has_value()) return false;
    const size_t bytesBefore = EstimatedMemoryBytes();
    EvictSubtree(*victim);
    CompactStorage();  // <-- O(N) compaction EVERY PASS
    ...
}
```

**Issue:** Each of the eight fine-grained passes does a full `CompactStorage()` (repacks ALL rows, rebuilds ALL indices). With tiny victims (single-file directories), eight passes = eight full O(N) compactions per ingestion batch. This is the **proven root cause of the 3.1M cliff** (WORKSTATE: "12-13 seconds enforcement versus ~0.17 seconds durable write per 8,192 rows").

**Reachable failure:** Sustained ingestion at 3M+ rows → every batch triggers enforcement → eight compactions/batch → ingestion throughput collapses.

**Regression adequacy:** `bench_ingestion_profile.cpp` measures this (WORKSTATE: "enforcement ~12.8s"). No unit test asserts compaction count or latency bound per batch.

**Smallest fix:** Batch evictions within a single compaction: collect up to *N* victims in the pass loop, erase all, then one `CompactStorage()`. Or change `EvictSubtree` to not require compaction (use `EvictVolume`-style bulk erase).

---

### Finding: P1 — `CompactEntriesForIterationOrder` called during search capture; can disturb cursor mid-iteration

**Location:** `IndexPipeline.cpp:1532–1538` (view-first capture path)

```cpp
if (!context.cursor.Next(entry)) {
    if (context.cursor.Stale()) { stale = true; break; }
    hotExhausted = true; break;
}
```

**Issue:** `CompactEntriesForIterationOrder()` is called from `RebuildVolumeFromStore` (Projection.cpp:1187) and `ShrinkBulkRebuildCapacity` (Projection.cpp:1262). If a search holds a `ProjectionEntryCursor` and a concurrent rebuild/compaction occurs (different thread? no — pipeline mutex serializes), the cursor's `Stale()` check catches it. **But**: the search captures `context.cursor` under mutex, releases mutex, then iterates. If *another* search triggers compaction (not possible — single pipeline mutex), or if compaction happens during the *same* search's mutex hold (not in current code), it's safe. However, `EnforceMemoryLimitNow()` calls `CompactStorage()` which calls `CompactEntriesForIterationOrder()` **while holding the mutex** (IndexPipeline.cpp:864, 969). A search holding the mutex in `captureContext` → releases → re-acquires for materialization could see a stale cursor if compaction happened between.

**Current mitigation:** `captureContext` takes `prepareProjection=true` and captures cursor **while holding mutex**. The cursor is used only while mutex is re-acquired for each chunk (IndexPipeline.cpp:1525, 1558). Between chunks, mutex is released. If enforcement runs in that window (unlikely — enforcement only at batch boundary), cursor goes stale → restart. Acceptable but fragile.

**Regression adequacy:** No test for cursor staleness across enforcement compaction during search. `TestLruTimestampsSurviveIterationOrderCompaction` tests compaction during rebuild, not during search.

---

### Finding: P2 — `SetMaximumMemoryBytes` re-enables enforcement temporarily during bulk scan

**Location:** `Projection.cpp:602–618` (`SetMaximumMemoryBytes`)

```cpp
const bool wasEnforcing = enforcingMemoryLimit_;
enforcingMemoryLimit_ = true;
EnforceMemoryLimitTo(maximumMemoryBytes_);
enforcingMemoryLimit_ = wasEnforcing;
```

**Issue:** During bulk scan (`SetBulkScanActive(true)` sets `enforcingMemoryLimit_ = false`), a call to `SetMaximumMemoryBytes` (e.g., from settings change) will **temporarily re-enable enforcement** and run `EnforceMemoryLimitTo`, which can evict data mid-scan. The comment says "An explicit limit change is synchronous and strict even during a bulk scan... must not be silently ignored" — but this violates the bulk-scan contract that defers compaction.

**Reachable failure:** Bulk scan ingestion (millions of rows) + user changes memory limit → mid-scan eviction + compaction → scan slowdown/corruption risk.

**Smallest fix:** In `SetMaximumMemoryBytes`, if `bulkScanActive_` is true, only update `maximumMemoryBytes_`; defer enforcement until `SetBulkScanActive(false)`.

---

### Finding: P2 — `RebuildVolumeFromStore` fail-fast estimate uses **current average row cost** but reloads a **different volume**

**Location:** `Projection.cpp:1148–1167` (`RebuildVolumeFromStore`)

```cpp
const size_t rowCount = EntryCount();
const size_t averageRowBytes = rowCount == 0 ? 512 : baseline / rowCount;
const size_t projected = expectedEntryCount > (lowWatermark / (averageRowBytes == 0 ? 1 : averageRowBytes))
    ? lowWatermark + 1
    : baseline + expectedEntryCount * averageRowBytes;
```

**Issue:** `averageRowBytes` is computed from **currently resident volumes**. The volume being reloaded may have very different row density (e.g., many small files vs few large files). The estimate can be wrong by 10x+, causing false fail-fast (rejecting a volume that would fit) or false pass (admitting a volume that triggers immediate re-eviction).

**Evidence:** Comment says "The estimate uses this projection's own measured average row cost against the early-enforcement watermark." No per-volume metadata stored.

**Smallest fix:** Store per-volume `estimatedBytes` in `VolumeMetadata` (durable) and use that for the reload projection. Or accept the approximation but document the error bound.

---

### Finding: P2 — `FilenameCandidateIndices` cap check uses `maximumCandidates` but **merges exceptional entries AFTER cap check**

**Location:** `Projection.cpp:1000–1012` and `1018–1040`

```cpp
if (maximumCandidates != 0 && result.size() > maximumCandidates) {
    return std::nullopt;  // cap check on posting intersection ONLY
}
// ... merge exceptional entries ...
if (maximumCandidates != 0 && merged.size() > maximumCandidates) {
    return std::nullopt;  // second cap check AFTER merge
}
```

**Issue:** If posting intersection yields 16,000 candidates (under 16,384 cap) but `filenameExceptionalEntries_` has 1,000 entries, merged = 17,000 → returns `nullopt` (fallback to canonical scan). The cap is effectively **lower** than configured when exceptional entries exist.

**Reachable failure:** Volume with many fold-exceptional names (CJK, surrogates) → selective queries that should use accelerator fall back to full scan, losing the 100x+ speedup.

**Regression adequacy:** `TestFilenameTrigramCandidatesTrackMutations` (test_projection.cpp:635–680) doesn't test cap boundary with exceptional entries. No test for mixed ASCII/exceptional corpus near cap.

**Smallest fix:** Check `result.size() + exceptionalCount > maximumCandidates` before merge, or reserve cap space for exceptional entries.

---

### Finding: P2 — `SearchIndexedReadPlane` generation restart limit (3) may be too low under memory pressure

**Location:** `IndexPipeline.h:85` (`kMaxGenerationRestarts = 3`)

**Issue:** Each structural change (eviction compaction, cold reload) bumps `queryVisibleEpoch` → search restarts. With eight enforcement passes per batch, each pass bumps epoch → **search restarts 8× per ingestion batch** if searches overlap. After 3 restarts, falls back to durable scan (slower).

**Evidence:** `AdvanceResidencyEpochsForStructuralChangeLocked` bumps epoch for **all volumes** (IndexPipeline.cpp:371–385), not just affected volume. A single volume eviction invalidates all in-flight searches.

**Regression adequacy:** No test for search restart frequency under sustained ingestion + concurrent search.

**Smallest fix:** Increase `kMaxGenerationRestarts` or make epoch bump per-volume (already has `volumeDataEpochs_` per-volume; `ProjectionResidency` reason currently bumps all).

---

### Finding: P2 — `ExportDirectorySnapshotBoundedPooled` reloads evicted volume **while holding mutex**, then iterates projection

**Location:** `IndexPipeline.cpp:1070–1165`

```cpp
std::lock_guard<std::mutex> lock(mutex_);
const bool wasCold = projection_.NeedsReload(id);
const bool reloaded = projection_.ReloadEvictedVolume(store_, id);  // may do I/O!
if (wasCold) AdvanceResidencyEpochsForStructuralChangeLocked();
...
projection_.ForEachEntry([&](...){ ... });  // holds mutex for entire export
```

**Issue:** `ReloadEvictedVolume` calls `RebuildVolumeFromStore` which does `store_.ForEachEntry` (SQLite streaming) **while holding the pipeline mutex**. This blocks all ingestion, searches, and other exports for the duration of the reload (can be seconds for large volumes).

**Reachable failure:** UI requests directory listing for a cold volume → entire engine stalls during reload.

**Smallest fix:** Release mutex during reload (like `GetFolderAggregate` does at IndexPipeline.cpp:1175–1180: opens read session **outside** mutex, then re-acquires only if hot). For export, collect volume IDs to reload, release mutex, reload, re-acquire, then export.

---

### Finding: P2 — `Projection::RemoveBatch` with `keepFilenameIndexCurrent=false` invalidates accelerator even for small batches

**Location:** `Projection.cpp:1296–1305`

```cpp
if (!keepFilenameIndexCurrent) {
    InvalidateFilenameIndex();
}
```

**Issue:** Contract says "keep=false leaves it invalidated regardless of batch size (review-lane C Finding 5: the small-batch path previously left it valid, contradicting the contract)." But `RemoveVolume` calls `RemoveBatch(..., false)` (Projection.cpp:1263), so **every `RemoveVolume` invalidates the filename accelerator**, even for 1-row volumes. `SetBulkScanActive(false)` then rebuilds it — but `ForgetVolume` → `RemoveVolume` → invalidates → no rebuild (IndexPipeline.cpp:992). Next search on other volumes loses accelerator.

**Regression adequacy:** `TestForgetVolumePurgesProjection` (test_index_pipeline.cpp:1428–1452) doesn't verify accelerator state on surviving volumes.

**Smallest fix:** Only invalidate if `frns.size() > kPerEntryFilenameRemovalThreshold` OR if this was the last volume (but accelerator is global). Better: make `RemoveBatch` with `keep=false` behave like `keep=true` for small batches (rebuild once), since `CompactStorage` after `RemoveVolume` already repacks everything.

---

### Finding: P2 — `RebuildAll` rule-prune reads **entire volume again** via `ForEachEntry` after rebuild

**Location:** `IndexPipeline.cpp:528–570`

```cpp
if (rebuildSucceeded && volumeRules_.find(meta.rowId) != volumeRules_.end()) {
    std::vector<EntryChange> ruleExcluded;
    const bool ruleReadSucceeded = store_.ForEachEntry(meta.rowId, [&](...){ ... });
    ...
}
```

**Issue:** `RebuildVolumeFromStore` already streamed all entries from store. Rule prune does a **second full scan** of the same volume. For 5M rows, this doubles rebuild I/O.

**Smallest fix:** During `RebuildVolumeFromStore`, evaluate inclusion rules on the fly (requires `volumeRules_` access in Projection, or pass rules to rebuild). Or cache the entries during rebuild.

---

### Finding: P2 — `SearchIndexedReadPlane` cold streaming uses `ColdNamePrefilterNeedle` but **does not verify FTS readiness**

**Location:** `IndexPipeline.cpp:1605–1625`

```cpp
const auto coldNamePrefilter = ColdNamePrefilterNeedle(searchRequest.query);
const bool streamed = !context.forceCanonicalColdScan && coldNamePrefilter.has_value()
    ? context.reader->ForEachEntryWithAsciiNameUntil(...)
    : context.reader->ForEachEntryUntil(...);
```

**Issue:** `ForEachEntryWithAsciiNameUntil` uses `entry_name_terms` (FTS5) table. If FTS index is not ready (state != 2), the query may return incomplete results. `Store::OpenReadSession` doesn't check FTS readiness; `StoreReadSession::ForEachEntryWithAsciiNameUntil` assumes ready.

**Evidence:** `Store.cpp` (not reviewed here) has `OpenReadSession` with `candidatePlannerProbe` but no readiness gate for cold search. The `durable-cold-search` spec requires FTS readiness validation.

**Regression adequacy:** `test_storage_pressure.cpp` `TestCandidateRecoveryRegressions` tests missing FTS table recovery on open, but not cold search on not-yet-ready FTS.

---

### Finding: P2 — `SnapshotPublisher` section name format uses process ID; **no session isolation** for multiple engine instances

**Location:** `SnapshotPublisher.h` (not read but referenced in `kSnapshotSectionNameFormat`)

**Issue:** AGENTS.md: "the engine publishes immutable, generation-named memory-mapped sections (`<session-prefix>.<instance>.<generation>`; see `kSnapshotSectionNameFormat`)". If multiple engine processes run (e.g., per-logon-session), they share the same global namespace. A stale section from a dead engine could be picked up by a new engine if generation numbers align.

**Current mitigation:** `SnapshotPublisher::Start` includes `GetCurrentProcessId()` in prefix. But process IDs recycle. No cleanup of abandoned sections on engine crash.

**Regression adequacy:** `TestPublisherUsesImmutableGenerations` (test_snapshot_publisher.cpp:18–85) tests single publisher. No test for cross-process section collision or cleanup.

---

### Finding: P2 — `Projection::RebuildFilenameIndex` builds trigram postings with `push_back` + sort/unique; **capacity not reserved** → multiple reallocations

**Location:** `Projection.cpp:1247–1270`

```cpp
filenameIndexBuilding_ = true;
idToIndex_.ForEachValue([&](const uint32_t index) { AddFilenameIndexEntry(index); });
for (auto& [trigram, posting] : filenameTrigramPostings_) {
    std::sort(posting.begin(), posting.end());
    posting.erase(std::unique(...), posting.end());
}
```

**Issue:** `AddFilenameIndexEntry` does `posting.push_back(index)` during `filenameIndexBuilding_` (no insert-sort). But `posting` vectors start empty → geometric reallocations for large volumes. `ShrinkBulkRebuildCapacity` later calls `shrink_to_fit`, but the reallocations during rebuild are unmeasured overhead.

**Smallest fix:** In `RebuildFilenameIndex`, first count trigrams per entry (or estimate), `reserve` posting vectors. Or use the existing `filenameIndexBuilding_` path to `push_back` then sort, but pre-reserve based on `idToIndex_.size()`.

---

### Finding: P2 — `FlatChildrenMap` child array stores **stale tail copies** after swap-removal; `LiveChildLinkCount()` vs `ChildCapacityBytes()` discrepancy

**Location:** `Projection.h:142` (comment) and `GetMemoryBreakdown` (Projection.cpp:835)

```cpp
// Live per-key child links (<= the flat array's length: swap-removal
// and slice relocation can leave stale tail copies in the array).
size_t childMapChildLinks = 0;  // LiveChildLinkCount()
size_t childMapChildBytes = 0;  // ChildCapacityBytes() -- includes stale copies
```

**Issue:** `FlatChildrenMap::remove` uses swap-with-last, leaving the swapped element's old value in the tail. `ChildCapacityBytes()` reports capacity including stale slots. `LiveChildLinkCount()` reports only live links. The delta is unmodeled memory (slack).

**Evidence:** `GetMemoryBreakdown` reports both but `modeledCategoryBytes` uses `childMapBytes` which includes full capacity. The slack is real memory not attributable to live data.

**Regression adequacy:** `TestRebuildReleasesBulkCapacitySlack` (test_projection.cpp:1300–1350) checks `childMapChildLinks == changes.size() - 1 && childMapChildBytes <= (links + links/8 + 16) * sizeof(uint32_t)` — verifies collapse after rebuild, but not during steady-state mutations.

---

### Finding: P2 — `IndexPipeline::FinishReconciliationPass` chunked removal uses **hardcoded 5,000 row chunks**

**Location:** `IndexPipeline.cpp:1115` (`kReconciliationRemovalChunkRows = 5'000`)

**Issue:** Hardcoded chunk size doesn't adapt to row size (names, metadata). 5,000 rows with 800-char names (crash test fixture) = large WAL per chunk. No configurability or dynamic sizing based on `kWalForceCheckpointThresholdBytes`.

**Regression adequacy:** `TestChunkTwoFull` (test_storage_pressure.cpp:600–670) exercises chunked removal with failure injection, but only at one chunk size.

---

### Unexecuted acceptance (not product bugs)

| Cell | Status | Evidence |
|------|--------|----------|
| Multi-volume memory pressure with LRU cross-volume eviction | NOT_EXECUTED | No test; single-volume benchmarks only |
| 5M-row ingestion with cold fallback path | NOT_EXECUTED | WORKSTATE: "Full no-probe 5M, current 3.1M-cliff runtime and larger resource/multi-volume/cap cells remain NOT_EXECUTED/disk-blocked" |
| Search restart frequency under sustained ingestion + concurrent search | NOT_EXECUTED | No test; `kMaxGenerationRestarts=3` unvalidated under load |
| Cold search on not-yet-ready FTS index | NOT_EXECUTED | `TestCandidateRecoveryRegressions` tests recovery on open, not query-time readiness |
| Snapshot publisher cross-process section collision/cleanup | NOT_EXECUTED | Single-process tests only |
| `ExportDirectorySnapshot` reload I/O under mutex blocking ingestion | NOT_EXECUTED | No latency test for export during reload |
| Reconciliation chunk size tuning / WAL bound verification | PARTIAL | `TestChunkTwoFull` tests failure injection, not sizing |

---

### Merge Verdict: **OK with notes**

**Rationale:** The implementation is **correct for the tested single-volume, degraded-mode path**. The memory eviction policy (8-pass fine-grained → whole-volume cold fallback) is a deliberate, documented trade-off with measured evidence (3.1M cliff). The code is well-structured, hardened against failure (fail-fast reload, atomic batch commit, epoch-based search invalidation), and has strong test coverage for the exercised paths.

**Required before production privileged-path validation:**
1. **P0 fix:** Whole-volume cold fallback on LRU entry — change to subtree eviction or add volume-level cap test.
2. **P1 fix:** `EvictSubtree` quadratic sibling unlink — batch erase + single compaction.
3. **P1 fix:** Eight compactions per enforcement cycle — batch victims, single compaction.
4. **P2 fix:** `SetMaximumMemoryBytes` during bulk scan — defer enforcement.
5. **P2 fix:** `ExportDirectorySnapshot` reload under mutex — release mutex during reload.
6. **Add regression tests** for multi-volume memory pressure, search restart under load, cold FTS readiness gate.

**Scope limitation:** This review inspected source at HEAD 2ff3b595 (executable 4c1c450) against the specified scope. Did not build, run tests, or verify benchmark numbers. Did not inspect `Store.cpp`, `FlatHashMap.h`, `SnapshotPublisher.cpp`, or `VolumeScanner.cpp` except as referenced. Historical review approvals (e.g., 3.1M benchmark) do not substitute for current evidence.

---

**Reviewed SHA:** `2ff3b595940d95c706fa815b72ffee1c8d53fb44` (PR15 HEAD) / executable `4c1c4501e5b1f0579a2d34f4f7afea5f83708979`  
**Scope:** Projection.cpp/.h, IndexPipeline.cpp/.h — memory/residency/eviction, search epochs, snapshots, cursors, cold fallback  
**Limitations:** Read-only source inspection; no build/test execution; no Store.cpp/FTS verification; no privileged-path validation