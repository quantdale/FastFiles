Now I have verified all the parent's corrections. Let me produce the corrected review artifact.

---

## Review (Corrected)

**Reviewed SHA**: 4c1c4501e5b1f0579a2d34f4f7afea5f83708979 (executable implementation) / 2ff3b595940d95c706fa815b72ffee1c8d53fb44 (PR15 HEAD)  
**Scope**: `src/indexstore/Store.h/.cpp`, `src/engine/IndexPipeline.h/.cpp`, `src/engine/VolumeSessionManager.h/.cpp`  
**Method**: Source inspection only; no builds, test execution, or runtime verification performed.

---

### Corrected Open Findings

| Severity | Issue | Location | Evidence |
|----------|-------|----------|----------|
| **P2** | **CROSS JOIN plan pin depends on SQLite planner honors `CROSS JOIN` hint** | `Store.cpp:2020-2055` (Stage 2 volume-scoped count) | Comment states "`CROSS JOIN` pins the driver" to force FTS→map→entries join order. SQLite *usually* honors `CROSS JOIN` as a join-order hint, but this is not guaranteed by the SQL standard. If a future SQLite version or unusual statistics caused a different plan, the count query could scan O(volume rows) instead of O(candidate rows). The `LIMIT ?3` (cap+1) bounds the *result*, not the *scan*, so a full scan could still be expensive before the limit applies. No test exercises planner misbehavior here. |
| **P2** | **Read-session move assignment clears readiness but inherits `failed_` flag** | `Store.cpp:1732-1745` | Move assignment calls `Close()` (rolls back transaction), then transfers `db_`, `transactionActive_`, `failed_`. If source had `failed_=true`, target inherits it. `Close()` on target would re-ROLLBACK the shared connection. Production never moves failed sessions; test-only. Low risk. |
| **P2** | **Global test seams (`gTestingGlobalAdmission`, `gTestingStagedDelivery`) are process-wide atomics** | `Store.cpp:285-297` | Tests run sequentially in CTest (one process per test exe). If parallelized, seams would interfere. `test_store_read_session.cpp` resets flags at end of each test. Latent isolation hazard. |
| **P2** | **`CheckpointIfWalExceeds` caches page size; not invalidated on `VACUUM`** | `Store.cpp:774-800` | `cachedPageSize_` queried once. `VacuumIfDue` runs `VACUUM` but doesn't invalidate cache. Production never changes page size (requires VACUUM with different `page_size` pragma, not used). No practical impact. |
| **P2** | **`TestFull` "commit" fault arm uses fragile trace-callback filter** | `test_storage_pressure.cpp:521-570` | Arms on `sqlFilter == "COMMIT" && inCommit` where `inCommit` set by `SQLITE_TRACE_STMT`/`PROFILE`. `COMMIT` via `sqlite3_exec` may not fire `TRACE_STMT`; relies on current SQLite behavior. Test passes today but filter is version-sensitive. |

---

### Historical Fixes (Verified in Source at 4c1c450 — Not Open Findings)

| Issue | Location | Fix Status |
|-------|----------|------------|
| Schema version read error treated as fresh v0 | `Store.cpp:527-534` | **Fixed**: Explicit `Valid() && step==ROW` guard; fails closed. `TestCandidateRecoveryRegressions` `version-read-interrupt` cell injects `SQLITE_DENY` via authorizer; open fails, `user_version` stays 4. |
| Missing-FTS repair recreated empty terms + ready marker on interrupt | `Store.cpp:439-452` | **Fixed**: Existence check *before* `CREATE`; missing structures → single transaction: recreate + invalidate marker + rebuild. `missing-table-interrupted-repair` cell injects `SQLITE_FULL` during clearing; retry converges. |
| Candidate readiness gate missing (silent truncation mid-rebuild) | `Store.cpp:1868-1891` | **Fixed**: `CandidateIndexUsable()` checks `state==1 && fold_signature==HostFoldSignature()` cached per session. `TestCandidateRungDegradesWhenIndexNotReady` red-first proves mid-rebuild (state=0) and host-mismatch degrade to canonical. |
| Candidate delivery not atomic (mid-stream failure leaked duplicates) | `Store.cpp:1945-2068` | **Fixed**: `stagedDelivery` (default true) buffers all rows before visitor; `CandidateStreamError` fault abandons atomically. `TestCandidateStreamFailureIsAtomic` proves zero duplicates under staged; legacy arm red-first leaks. |
| Reconciliation single giant transaction (960 MB WAL at 2M) | `IndexPipeline.cpp:1065-1142` | **Fixed**: 5k-row chunks, each own committed transaction + checkpoint. Committed prefix mirrored to projection in one bulk `RemoveBatch`. `TestChunkTwoFull` injects `SQLITE_FULL` at 2nd chunk: 5000 committed removals retained, obligation retained, epoch advances. |
| Metadata finalization advanced on `ScanComplete` regardless of removal success | `VolumeSessionManager.cpp:1060-1080` | **Fixed**: `retryFinalization` lambda captures `wasReconciliationScan \|\| deferred`; installs retry on *any* finalization failure. `ClearRetryOwnerLocked` only after `MarkScanComplete` AND `SetLastReconciliationTime` succeed. |
| Failed reconciliation identity enumeration treated as exhaustion | `IndexPipeline.cpp:1075-1082` | **Fixed**: Early return on `!enumerationSucceeded`; pass retained, no removals. `TestReconciliationReadFailureRetainsObligation` injects progress-handler interrupt; retry converges. |
| Manager `TriggerReconciliation` loses `reconciliation` kind on `SendRequest` failure | `VolumeSessionManager.cpp:806, 842` | **Already fixed in source**: Line 806 `ClaimActiveAttemptLocked(..., /*reconciliation=*/true)`; line 842 `RearmFailedAdmissionLocked(..., /*reconciliation=*/true)`. **Not a current bug** — my prior P1 finding was incorrect. |

---

### Tests Inspected (Source Only — Not Executed)

- `tests/indexstore/test_store.cpp`: `TestSchemaV1ToV2MigrationInPlace`, `TestIntegrityVerdictClassifier`, `TestLockedDatabaseFailsOpenWithoutIntegrityFlag`, `TestCorruptDatabaseSetsIntegrityFailedFlag`, `TestPartialUpsertOfMissingRowZeroesAbsentFields`
- `tests/indexstore/test_store_read_session.cpp`: `TestCandidateRungDegradesWhenIndexNotReady`, `TestCandidateStreamFailureIsAtomic`, `TestCandidateStreamCancellationStopsCleanly`, `TestCandidateAdmissionIsVolumeScoped`, `TestCandidateAdmissionCountsExceptionCandidates`, `TestCandidateAdmissionLocallyBroadFallsBack`, `TestCandidateCapFallsBackToCanonicalScan`, `TestDurableCandidateSupersetAcrossAdversarialNames`, `TestAsciiNamePrefilterIsConservativeAndPrecise`, `TestReadSessionFaultsFailClosed`
- `tests/engine/test_volume_session_manager.cpp`: `TestScanFailedLeavesPriorIndexAuthorityIntact`, `TestScanFailedSchedulesRetry`, `TestPauseResumeHonorsPendingScanFailureFloor`, `TestFailedReconciliationRetrySurvivesDisconnect`, `TestScanFailedRacingDisconnectFromPublicationKeepsRetryOwner`, `TestSchedulerDispatchRacingDisconnectKeepsRetryOwner`
- `tests/engine/test_storage_pressure.cpp`: `TestReaders`, `TestFull`, `TestRebuildFull`, `TestCandidateRecoveryRegressions`, `TestChunkTwoFull`, `TestReconciliationReadFailureRetainsObligation`, `TestCrash` (opt-in `--crash-acceptance`)

---

### Verdict: **OK with notes**

**Rationale**: All P0/P1 issues in the review scope are **fixed in 4c1c450** and have corresponding non-vacuous test cases (real SQLite error injection via forwarding VFS, real WAL recovery logic, real progress-handler interrupts). The one P1 I originally reported (manager losing `deferred` kind) **does not exist** — the fix is already at `VolumeSessionManager.cpp:842`. Remaining items are P2: planner-hint speculation, test-seam isolation, and fragile trace-callback filter — none are correctness bugs.

**Notes**:
1. The `CROSS JOIN` plan pin is a deliberate optimization with measured 40× regression before the pin; the `LIMIT` bounds results but not scan cost. Monitor if planner behavior changes.
2. Global test seams should be moved to per-session context if parallel test execution is ever adopted.
3. Opt-in crash acceptance test (`--crash-acceptance`) covers additional WAL-recovery-after-unclean-shutdown dimension not run in default CI.

**Limitations**: Source-only review; no build/test execution. `Projection.cpp` not reviewed for `ListEntryIds` callers (reconciliation path is the only durable caller and is fixed). PR16 (e75a230) not integrated — Gallery dependency remains open (task 5.12). Hosted CI `BLOCKED_EXTERNAL`.